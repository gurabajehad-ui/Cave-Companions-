import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Bell,
  CheckCircle2,
  Sparkles,
  ShoppingBag,
  AlertTriangle,
  Shield,
  Megaphone,
  CheckCheck,
  Filter,
  ArrowLeft,
  Clock,
  Inbox
} from 'lucide-react';
import { api } from '../services/api';
import { NotificationItem, NotificationType } from '../types';
import { formatBnDate, formatBnTime } from '../data/prayerConfig';
import { PrayerReminderCard } from './PrayerReminderCard';

interface NotificationsViewProps {
  onBack?: () => void;
  onShowToast: (type: 'success' | 'error' | 'info', title: string, msg: string) => void;
  onNotificationReadChange?: (unreadCount: number) => void;
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({
  onBack,
  onShowToast,
  onNotificationReadChange
}) => {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const fetchNotifications = async () => {
    try {
      setLoading(true);
      const res = await api.getNotifications();
      setNotifications(res.notifications);
      setUnreadCount(res.unreadCount);
      if (onNotificationReadChange) {
        onNotificationReadChange(res.unreadCount);
      }
    } catch (err: any) {
      console.error('Failed to load notifications:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, []);

  const handleMarkAsRead = async (id: string) => {
    try {
      const res = await api.markNotificationRead(id);
      setNotifications(prev =>
        prev.map(n => (n.id === id ? { ...n, read: true } : n))
      );
      setUnreadCount(res.unreadCount);
      if (onNotificationReadChange) {
        onNotificationReadChange(res.unreadCount);
      }
    } catch (err: any) {
      onShowToast('error', 'ত্রুটি', 'বিজ্ঞপ্তি আপডেট করা যায়নি।');
    }
  };

  const handleMarkAllAsRead = async () => {
    if (unreadCount === 0) return;
    try {
      const res = await api.markAllNotificationsRead();
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      setUnreadCount(0);
      if (onNotificationReadChange) {
        onNotificationReadChange(0);
      }
      onShowToast('success', 'সফল', 'সকল বিজ্ঞপ্তি পড়া হয়েছে হিসেবে চিহ্নিত করা হয়েছে।');
    } catch (err: any) {
      onShowToast('error', 'ত্রুটি', 'বিজ্ঞপ্তি আপডেট করা যায়নি।');
    }
  };

  const getTypeIcon = (type: NotificationType) => {
    switch (type) {
      case 'PRAYER_VERIFIED':
        return <CheckCircle2 className="w-5 h-5 text-emerald-400" />;
      case 'TOKEN_EARNED':
        return <Sparkles className="w-5 h-5 text-amber-400" />;
      case 'TOKEN_REDEEMED':
        return <ShoppingBag className="w-5 h-5 text-teal-400" />;
      case 'REDEMPTION_FAILED':
        return <AlertTriangle className="w-5 h-5 text-rose-400" />;
      case 'SECURITY':
        return <Shield className="w-5 h-5 text-blue-400" />;
      case 'ANNOUNCEMENT':
      default:
        return <Megaphone className="w-5 h-5 text-indigo-400" />;
    }
  };

  const getTypeBadge = (type: NotificationType) => {
    switch (type) {
      case 'PRAYER_VERIFIED':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-950/80 text-emerald-300 border border-emerald-700/50">সালাত ভেরিফাইড</span>;
      case 'TOKEN_EARNED':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-950/80 text-amber-300 border border-amber-700/50">টোকেন অর্জিত</span>;
      case 'TOKEN_REDEEMED':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-teal-950/80 text-teal-300 border border-teal-700/50">রিডিম সম্পন্ন</span>;
      case 'REDEMPTION_FAILED':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-950/80 text-rose-300 border border-rose-700/50">রিডেম্পশন সতর্কতা</span>;
      case 'SECURITY':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-950/80 text-blue-300 border border-blue-700/50">নিরাপত্তা</span>;
      case 'ANNOUNCEMENT':
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-950/80 text-indigo-300 border border-indigo-700/50">ঘোষণা</span>;
    }
  };

  const filteredNotifications = notifications.filter(n => {
    if (filter === 'unread') return !n.read;
    return true;
  });

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-5 pb-24 text-slate-100">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {onBack && (
            <button
              onClick={onBack}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <div>
            <h1 className="text-xl font-bold text-white flex items-center gap-2">
              <Bell className="w-5 h-5 text-amber-400" />
              বিজ্ঞপ্তি (Notifications)
            </h1>
            <p className="text-xs text-slate-400">সালাত ভেরিফিকেশন, ১০ মিনিট পূর্বের রিমাইন্ডার ও টোকেন আপডেট</p>
          </div>
        </div>

        {unreadCount > 0 && (
          <button
            onClick={handleMarkAllAsRead}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-xs font-semibold text-amber-400 transition-colors"
          >
            <CheckCheck className="w-4 h-4" />
            <span>সব পড়া হয়েছে</span>
          </button>
        )}
      </div>

      {/* 10-Min Prayer Time Local Push Reminder Settings */}
      <PrayerReminderCard onShowToast={onShowToast} />

      {/* Filter Tabs */}
      <div className="flex gap-2 p-1 bg-slate-900 border border-slate-800 rounded-2xl">
        <button
          onClick={() => setFilter('all')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
            filter === 'all'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          সকল বিজ্ঞপ্তি ({notifications.length})
        </button>
        <button
          onClick={() => setFilter('unread')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all relative ${
            filter === 'unread'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          অপঠিত
          {unreadCount > 0 && (
            <span className="ml-1.5 px-1.5 py-0.5 rounded-full text-[10px] bg-rose-500 text-white font-bold">
              {unreadCount}
            </span>
          )}
        </button>
      </div>

      {/* Notification List */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(i => (
            <div key={i} className="animate-pulse bg-slate-900/60 border border-slate-800 rounded-2xl p-4 h-24" />
          ))}
        </div>
      ) : filteredNotifications.length === 0 ? (
        <div className="text-center py-16 bg-slate-900/30 border border-dashed border-slate-800 rounded-3xl p-6">
          <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500">
            <Inbox className="w-7 h-7" />
          </div>
          <h3 className="text-sm font-bold text-slate-300">কোনো বিজ্ঞপ্তি নেই</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
            {filter === 'unread'
              ? 'আপনার সব বিজ্ঞপ্তি পড়া হয়েছে।'
              : 'সালাত ভেরিফিকেশন ও টোকেন অর্জনের পর এখানে বিজ্ঞপ্তি দেখতে পাবেন।'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          <AnimatePresence>
            {filteredNotifications.map(notification => (
              <motion.div
                key={notification.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className={`p-4 rounded-2xl border transition-all relative ${
                  !notification.read
                    ? 'bg-gradient-to-br from-slate-900/90 via-slate-900/80 to-emerald-950/40 border-emerald-600/50 shadow-lg'
                    : 'bg-slate-900/40 border-slate-800/80 hover:border-slate-700 opacity-90'
                }`}
              >
                <div className="flex items-start gap-3.5">
                  <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800/80 shrink-0">
                    {getTypeIcon(notification.type)}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center justify-between gap-1.5 mb-1">
                      <div className="flex items-center gap-2">
                        <h4 className={`text-sm font-bold truncate ${!notification.read ? 'text-white' : 'text-slate-300'}`}>
                          {notification.title}
                        </h4>
                        {!notification.read && (
                          <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" title="নতুন" />
                        )}
                      </div>
                      {getTypeBadge(notification.type)}
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed break-words mb-2">
                      {notification.message}
                    </p>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-800/40">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-400" />
                        {new Date(notification.createdAt).toLocaleDateString('bn-BD', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric'
                        })} • {new Date(notification.createdAt).toLocaleTimeString('bn-BD', {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>

                      {!notification.read && (
                        <button
                          onClick={() => handleMarkAsRead(notification.id)}
                          className="text-[11px] text-emerald-400 hover:text-emerald-300 font-semibold px-2 py-0.5 rounded bg-emerald-950/40 border border-emerald-800/50 hover:bg-emerald-950/80 transition-colors"
                        >
                          পড়া হয়েছে হিসেবে চিহ্নিত করুন
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
};
