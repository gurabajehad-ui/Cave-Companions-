import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { HelpCircle, X, CheckCircle2, QrCode, Award, ShieldCheck, BookOpen, Mail, Phone, MessageCircle, PhoneForwarded } from 'lucide-react';
import { HADITHS } from '../data/prayerConfig';
import { api } from '../services/api';

interface HelpSupportModalProps {
  onClose: () => void;
}

interface HelplineData {
  isActive: boolean;
  primaryPhone: string;
  secondaryPhone?: string;
  whatsappNumber?: string;
  supportEmail?: string;
  supportMessage: string;
  isWhatsappEnabled: boolean;
}

export const HelpSupportModal: React.FC<HelpSupportModalProps> = ({ onClose }) => {
  const [nasihaList, setNasihaList] = useState<any[]>([]);
  const [helpline, setHelpline] = useState<HelplineData | null>(null);

  useEffect(() => {
    api.getPublicNasihaList()
      .then(res => {
        if (res.success && Array.isArray(res.list) && res.list.length > 0) {
          setNasihaList(res.list);
        }
      })
      .catch(err => console.error('Failed to load nasiha list:', err));

    api.getHelpline()
      .then(res => {
        if (res && res.success !== false) {
          setHelpline({
            isActive: res.isActive !== undefined ? res.isActive : true,
            primaryPhone: res.primaryPhone || '+880 1700-000000',
            secondaryPhone: res.secondaryPhone,
            whatsappNumber: res.whatsappNumber,
            supportEmail: res.supportEmail || 'support@cavecompanions.org',
            supportMessage: res.supportMessage || 'সাহায্যের জন্য ২৪-৪৮ ঘণ্টার মধ্যে আমাদের টিম আপনার অনুরোধটি রিভিউ করবে। জরুরি কোনো সাহায্যের প্রয়োজন হলে আমাদের হেল্পলাইনে যোগাযোগ করতে পারেন।',
            isWhatsappEnabled: Boolean(res.isWhatsappEnabled)
          });
        }
      })
      .catch(err => console.error('Failed to load helpline info:', err));
  }, []);

  const displayNasiha = nasihaList.length > 0 ? nasihaList : HADITHS;

  const faqs = [
    {
      q: 'কেভ কম্প্যানিয়ন্স কীভাবে কাজ করে?',
      a: 'প্রতি ওয়াক্তে মসজিদে গিয়ে জামাতে নামাজ সম্পন্ন করার পর মসজিদের নির্দিষ্ট QR কোডটি অ্যাপ দিয়ে স্ক্যান করুন। সার্ভার তাৎক্ষণিকভাবে যাচাই করে আপনার উপস্থিতির রেকর্ড সংরক্ষণ করবে।'
    },
    {
      q: 'একই নামাজ কি দিনে একাধিকবার স্ক্যান করা যাবে?',
      a: 'না। একজন ব্যবহারকারী একটি ওয়াক্তের নামাজ দিনে কেবল একবারই জামাতে সম্পন্ন হিসেবে ভেরিফাই করতে পারবেন।'
    },
    {
      q: 'টোকেনগুলো কী এবং কখন পাওয়া যাবে?',
      a: 'দৈনিক ৫ ওয়াক্ত জামাতে গোল্ড, ৪ ওয়াক্তে সিলভার এবং ৩ ওয়াক্তে ব্রোঞ্জ টোকেন অর্জনের যোগ্যতা তৈরি হয়। টোকেন জেনারেশন এবং রিডেম্পশন ফেজ ৪ এবং ফেজ ৬-এ আনুষ্ঠানিকভাবে চালু হবে।'
    },
    {
      q: 'আমাদের মসজিদের কিউআর কোড যুক্ত করতে কী করতে হবে?',
      a: 'মসজিদ কমিটি বা ইমাম সাহেব আমাদের সাপোর্ট টিমের সাথে যোগাযোগ করে বিনামূল্যে মসজিদ নিবন্ধন ও অফিসিয়াল কিউআর কোড সংগ্রহ করতে পারবেন।'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="w-full max-w-lg bg-slate-950 border border-emerald-700/60 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="bg-emerald-950 px-5 py-4 border-b border-emerald-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-800 flex items-center justify-center text-amber-300">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white leading-tight">
                সাহায্য ও নিয়মাবলী (Help & FAQ)
              </h2>
              <p className="text-xs text-emerald-300/80 mt-0.5">
                জামাতে সালাত ও অ্যাপ ব্যবহারের নির্দেশিকা
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-emerald-900/60 text-emerald-200 hover:text-white hover:bg-emerald-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-6 flex-1 text-slate-100">
          {/* Step by step guide */}
          <div>
            <h3 className="text-xs font-bold text-emerald-400 uppercase tracking-wider mb-3">
              কীভাবে নামাজ ভেরিফাই করবেন?
            </h3>
            <div className="space-y-2.5 text-xs text-slate-300">
              <div className="flex items-start gap-2.5 p-3 rounded-2xl bg-slate-900 border border-slate-800">
                <span className="w-5 h-5 rounded-full bg-emerald-950 text-amber-300 border border-emerald-700/50 flex items-center justify-center font-bold text-[10px] shrink-0">
                  ১
                </span>
                <p>ওয়াক্তমত নিবন্ধিত যেকোনো মসজিদে জামাতে নামাজ আদায় করুন।</p>
              </div>

              <div className="flex items-start gap-2.5 p-3 rounded-2xl bg-slate-900 border border-slate-800">
                <span className="w-5 h-5 rounded-full bg-emerald-950 text-amber-300 border border-emerald-700/50 flex items-center justify-center font-bold text-[10px] shrink-0">
                  ২
                </span>
                <p>হোম স্ক্রিনে ওই ওয়াক্তের কার্ডে "আলহামদুলিল্লাহ্ সম্পন্ন করেছি" বাটনে ট্যাপ করুন।</p>
              </div>

              <div className="flex items-start gap-2.5 p-3 rounded-2xl bg-slate-900 border border-slate-800">
                <span className="w-5 h-5 rounded-full bg-emerald-950 text-amber-300 border border-emerald-700/50 flex items-center justify-center font-bold text-[10px] shrink-0">
                  ৩
                </span>
                <p>ক্যামেরা দিয়ে মসজিদের দেওয়ালে থাকা অফিসিয়াল QR কোডটি স্ক্যান করলেই ভেরিফিকেশন সম্পন্ন হবে।</p>
              </div>
            </div>
          </div>

          {/* Hadiths section */}
          <div>
            <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <BookOpen className="w-4 h-4" />
              <span>নসিহা</span>
            </h3>
            <div className="space-y-3">
              {displayNasiha.map((h, i) => (
                <div key={h.id || i} className="p-3.5 rounded-2xl bg-emerald-950/60 border border-emerald-700/40 text-xs">
                  <p className="text-emerald-100 leading-relaxed italic">"{h.textBn}"</p>
                  {h.sourceBn && <p className="text-[11px] text-amber-300/80 mt-1 font-medium text-right">— {h.sourceBn}</p>}
                </div>
              ))}
            </div>

          </div>

          {/* FAQ section */}
          <div>
            <h3 className="text-xs font-bold text-emerald-400 uppercase tracking-wider mb-3">
              সচরাচর জিজ্ঞাসিত প্রশ্ন (FAQ)
            </h3>
            <div className="space-y-3">
              {faqs.map((faq, index) => (
                <div key={index} className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs">
                  <p className="font-bold text-white mb-1">প্রশ্ন: {faq.q}</p>
                  <p className="text-slate-300 leading-relaxed">উত্তর: {faq.a}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Support contacts */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
            <h4 className="font-bold text-white flex items-center gap-2">
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>যোগাযোগ ও সহায়তা</span>
            </h4>
            <p className="text-slate-400 leading-relaxed">
              {helpline?.supportMessage || 'কোনো সমস্যা বা পরামর্শের জন্য আমাদের সাথে যোগাযোগ করতে পারেন:'}
            </p>

            <div className="pt-1 space-y-2 text-slate-200">
              {/* Dynamic Helpline Numbers if Active */}
              {helpline?.isActive !== false && helpline?.primaryPhone && (
                <a
                  href={`tel:${helpline.primaryPhone.replace(/\s+/g, '')}`}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/60 text-emerald-300 hover:bg-emerald-900/40 transition-colors"
                >
                  <span className="flex items-center gap-2 font-mono font-bold">
                    <Phone className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{helpline.primaryPhone}</span>
                  </span>
                  <span className="text-[10px] bg-emerald-600/80 text-white font-bold px-2 py-0.5 rounded-lg">
                    কল করুন
                  </span>
                </a>
              )}

              {helpline?.isActive !== false && helpline?.secondaryPhone && (
                <a
                  href={`tel:${helpline.secondaryPhone.replace(/\s+/g, '')}`}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-blue-950/40 border border-blue-800/60 text-blue-300 hover:bg-blue-900/40 transition-colors"
                >
                  <span className="flex items-center gap-2 font-mono font-bold">
                    <PhoneForwarded className="w-3.5 h-3.5 text-blue-400" />
                    <span>{helpline.secondaryPhone}</span>
                  </span>
                  <span className="text-[10px] bg-blue-600/80 text-white font-bold px-2 py-0.5 rounded-lg">
                    বিকল্প কল
                  </span>
                </a>
              )}

              {/* Dynamic WhatsApp Support */}
              {helpline?.isActive !== false && helpline?.isWhatsappEnabled && helpline?.whatsappNumber && (
                <a
                  href={`https://wa.me/${helpline.whatsappNumber.replace(/\D/g, '')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-2.5 rounded-xl bg-green-950/40 border border-green-800/60 text-green-300 hover:bg-green-900/40 transition-colors"
                >
                  <span className="flex items-center gap-2 font-mono font-bold">
                    <MessageCircle className="w-3.5 h-3.5 text-green-400" />
                    <span>হোয়াটসঅ্যাপ: {helpline.whatsappNumber}</span>
                  </span>
                  <span className="text-[10px] bg-green-600/80 text-white font-bold px-2 py-0.5 rounded-lg">
                    মেসেজ
                  </span>
                </a>
              )}

              {/* Support Email */}
              {helpline?.supportEmail && (
                <a
                  href={`mailto:${helpline.supportEmail}`}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-slate-300 hover:bg-slate-800/60 transition-colors"
                >
                  <span className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-amber-400" />
                    <span>{helpline.supportEmail}</span>
                  </span>
                  <span className="text-[10px] bg-slate-800 text-slate-300 font-bold px-2 py-0.5 rounded-lg border border-slate-700">
                    ইমেইল
                  </span>
                </a>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-900 px-5 py-3 border-t border-slate-800 text-center">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>
      </motion.div>
    </div>
  );
};

