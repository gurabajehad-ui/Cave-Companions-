import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import type { Advertisement } from '../types';

interface AdBannerProps {
  pageName: string;
  placementSlot: string;
}

const getDestinationLabel = (type: string) => {
  switch (type) {
    case 'EXTERNAL': return 'ভিজিট করুন ➔';
    case 'PARTNER_SHOP': return 'শপ প্রোডাক্ট দেখুন ➔';
    case 'PRODUCT': return 'ডিজিটাল প্রোডাক্ট ও সেবা ➔';
    case 'APP_PAGE': return 'বিস্তারিত পেইজ দেখুন ➔';
    default: return 'বিস্তারিত দেখতে ক্লিক করুন ➔';
  }
};

export default function AdBanner({ pageName, placementSlot }: AdBannerProps) {
  const [ads, setAds] = useState<Advertisement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    const fetchAds = async () => {
      setLoading(true);
      try {
        const normalizedPageName = String(pageName || '').toUpperCase().trim();
        const normalizedPlacementSlot = String(placementSlot || '').toUpperCase().trim();
        const fetchedAds = await api.getAdsForPage(normalizedPageName, normalizedPlacementSlot);
        if (mounted) setAds(Array.isArray(fetchedAds) ? fetchedAds : []);
      } catch (err) {
        console.error('[AdBanner] Ad fetch error:', err);
      }
      if (mounted) setLoading(false);
    };
    fetchAds();
    return () => { mounted = false; };
  }, [pageName, placementSlot]);

  if (loading || !Array.isArray(ads) || ads.length === 0) return null;

  return (
    <div className="w-full space-y-4 my-4 flex flex-col items-center">
      {ads.map((ad, index) => {
        // Properties are directly on the ad object from the backend API
        const displaySize = (ad as any).displaySize;
        const spaceProfile = (ad as any).spaceProfile;
        
        // Compact outer margins based on space profile
        let spaceClass = 'my-2';
        if (spaceProfile === 'COMPACT') spaceClass = 'my-1';
        else if (spaceProfile === 'EXPANDED') spaceClass = 'my-4';
        
        // Strictly control width and height based on S/M/L
        let sizeClass = 'w-full max-w-lg'; 
        let heightClass = 'h-60'; // 10 lines height (240px / 15rem)
        
        if (displaySize === 'SMALL') {
          sizeClass = 'w-56 sm:w-64';
          heightClass = 'h-40'; // Smaller banner height
        } else if (displaySize === 'MEDIUM') {
          sizeClass = 'w-80 sm:w-96';
          heightClass = 'h-48'; // Medium banner height
        } else if (displaySize === 'LARGE') {
          sizeClass = 'w-full max-w-lg';
          heightClass = 'h-60'; // 10 lines height (240px)
        }

        const handleAdClick = () => {
          const destType = String(ad.destinationType || '').toUpperCase().trim();
          const destId = String(ad.destinationId || '').trim();
          
          const isExternal = destType === 'EXTERNAL_URL' || destType === 'EXTERNAL';
          const isShop = destType === 'PARTNER_SHOP' || destType === 'SHOP';
          const isAppPage = destType === 'INTERNAL_APP_PAGE' || destType === 'APP_PAGE';

          const triggerHashAndNavigation = (newHash: string, tabName: string) => {
            window.location.hash = newHash;
            if ((window as any).setAppActiveTab) {
              (window as any).setAppActiveTab(tabName);
            }
            // Manually dispatch hashchange event to trigger listener in other active components (e.g., ShopsView)
            window.dispatchEvent(new HashChangeEvent('hashchange'));
          };

          if (isExternal && ad.externalUrl) {
            window.open(ad.externalUrl, '_blank');
          } else if (isShop && destId) {
            const targetHash = destId.startsWith('#') 
              ? destId 
              : (destId.startsWith('shop-') ? `#${destId}` : `#shop-${destId}`);
            triggerHashAndNavigation(targetHash, 'shops');
          } else if (isAppPage && destId) {
            const d = destId.toLowerCase();
            if (d.includes('মার্কেট') || d.includes('market') || d.includes('cave_market') || d.includes('cavemarket')) {
              triggerHashAndNavigation('#market', 'market');
            } else if (d.includes('হোম') || d.includes('home')) {
              triggerHashAndNavigation('#home', 'home');
            } else if (d.includes('টোকেন') || d.includes('token')) {
              triggerHashAndNavigation('#tokens', 'tokens');
            } else if (d.includes('শপ') || d.includes('shop')) {
              triggerHashAndNavigation('#shops', 'shops');
            } else if (d.includes('প্রোফাইল') || d.includes('profile')) {
              triggerHashAndNavigation('#profile', 'profile');
            } else if (d.includes('মার্চেন্ট') || d.includes('merchant')) {
              triggerHashAndNavigation('#merchant', 'merchant');
            } else if (d.includes('অ্যাডমিন') || d.includes('admin')) {
              triggerHashAndNavigation('#admin', 'admin');
            } else if (d.includes('সাপোর্ট') || d.includes('support')) {
              triggerHashAndNavigation('#support', 'support');
            } else if (d.includes('নোটিফিকেশন') || d.includes('notification')) {
              triggerHashAndNavigation('#notifications', 'notifications');
            } else if (d.includes('ইতিহাস') || d.includes('history') || d.includes('জার্নি') || d.includes('journey')) {
              triggerHashAndNavigation('#prayer_journey', 'prayer_journey');
            } else {
              const cleanedHash = destId.startsWith('#') ? destId : `#${destId}`;
              const guessedTab = destId.startsWith('#') ? destId.substring(1) : destId;
              triggerHashAndNavigation(cleanedHash, guessedTab);
            }
          }
        };

        if (!ad.imageUrl) return null;

        return (
          <div 
            key={`${ad.id}-${index}`} 
            className={`transition-transform duration-200 hover:scale-[1.01] cursor-pointer rounded-xl overflow-hidden shadow-sm border border-slate-200/50 bg-white ${spaceClass} ${sizeClass}`}
            onClick={handleAdClick}
          >
            {/* IMAGE ONLY LAYOUT */}
            <div className={`relative ${heightClass} w-full overflow-hidden`}>
              <img 
                src={ad.imageUrl} 
                alt={ad.title || 'Advertisement'} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}
