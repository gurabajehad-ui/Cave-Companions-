import React from 'react';
import { Home, Coins, Store, UserCheck, ShoppingBag } from 'lucide-react';
import { ActiveTab } from '../types';

interface BottomNavProps {
  activeTab: ActiveTab;
  onChangeTab: (tab: ActiveTab) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onChangeTab }) => {
  const navItems = [
    {
      id: 'home' as ActiveTab,
      labelBn: 'হোম',
      labelEn: 'Home',
      icon: Home
    },
    {
      id: 'tokens' as ActiveTab,
      labelBn: 'আমার টোকেন',
      labelEn: 'My Token',
      icon: Coins,
      badge: '🪙'
    },
    {
      id: 'shops' as ActiveTab,
      labelBn: 'পার্টনার শপ',
      labelEn: 'Shops',
      icon: Store,
      badge: 'ছাড়'
    },
    {
      id: 'market' as ActiveTab,
      labelBn: 'কেভ মার্কেট',
      labelEn: 'Cave Market',
      icon: ShoppingBag,
      badge: 'নতুন'
    },
    {
      id: 'profile' as ActiveTab,
      labelBn: 'প্রোফাইল',
      labelEn: 'Profile',
      icon: UserCheck
    }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-emerald-950/95 backdrop-blur-lg border-t border-emerald-800/80 shadow-2xl">
      <div className="max-w-md mx-auto grid grid-cols-5 px-2 py-1.5">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onChangeTab(item.id)}
              className={`relative flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all duration-200 ${
                isActive
                  ? 'text-amber-300 font-semibold'
                  : 'text-emerald-300/70 hover:text-emerald-100 hover:bg-emerald-900/40'
              }`}
            >
              {isActive && (
                <span className="absolute top-0 w-8 h-1 bg-amber-400 rounded-full shadow-[0_0_8px_rgba(251,191,36,0.6)]" />
              )}

              <div className="relative mt-0.5">
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
                {item.badge && (
                  <span className="absolute -top-1.5 -right-3 text-[8px] font-bold px-1 py-0.2 rounded-full bg-amber-500/30 text-amber-200 border border-amber-400/40 leading-none">
                    {item.badge}
                  </span>
                )}
              </div>

              <span className="text-[11px] mt-1 tracking-tight truncate max-w-full">
                {item.labelBn}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
