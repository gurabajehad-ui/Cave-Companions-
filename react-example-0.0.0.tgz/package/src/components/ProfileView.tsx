import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import {
  User,
  Phone,
  Calendar,
  ShieldCheck,
  LogOut,
  Edit2,
  Award,
  Clock,
  MapPin,
  CheckCircle2,
  Activity,
  Sparkles,
  History,
  Store,
  X
} from 'lucide-react';
import { api } from '../services/api';
import { PrayerAttendance, UserLifetimeStats } from '../types';
import { BANGLADESH_DISTRICTS } from '../data/bangladeshGeo';
import { toBnNumber, formatBnDate, formatBnTime, PRAYERS_CONFIG } from '../data/prayerConfig';

interface ProfileViewProps {
  onLogout: () => void;
  onShowToast: (type: 'success' | 'error' | 'info', title: string, msg: string) => void;
  onNavigateTab?: (tab: string) => void;
  onOpenLegal?: (type: 'privacy' | 'terms' | 'about') => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  onLogout,
  onShowToast,
  onNavigateTab,
  onOpenLegal
}) => {
  const { user, userStats, updateProfile, refreshUser } = useAuth();

  // Edit profile state
  const [isEditing, setIsEditing] = useState(false);
  const [newName, setNewName] = useState(user?.fullName || '');
  const [newDistrict, setNewDistrict] = useState(user?.district || '');
  const [newUpazila, setNewUpazila] = useState(user?.upazila || '');
  const [newAddress, setNewAddress] = useState(user?.address || '');
  const [savingProfile, setSavingProfile] = useState(false);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    setSavingProfile(true);
    try {
      const ok = await updateProfile({
        fullName: newName.trim(),
        district: newDistrict.trim() || undefined,
        upazila: newUpazila.trim() || undefined,
        address: newAddress.trim() || undefined
      });
      if (ok) {
        onShowToast('success', 'সফল', 'প্রোফাইল তথ্য সফলভাবে পরিবর্তন করা হয়েছে।');
        setIsEditing(false);
      }
    } catch (err: any) {
      onShowToast('error', 'ত্রুটি', err.message || 'আপডেট করতে ব্যর্থ হয়েছে।');
    } finally {
      setSavingProfile(false);
    }
  };

  if (!user) return null;

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-6 pb-24 text-slate-100">
      {/* Profile Header Card */}
      <div className="bg-gradient-to-br from-emerald-950 via-emerald-900 to-teal-950 border border-emerald-700/60 rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-center gap-5 relative z-10 text-center sm:text-left">
          {/* Avatar */}
          <div className="relative">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-emerald-600 to-amber-500 p-0.5 shadow-lg">
              <div className="w-full h-full bg-emerald-950 rounded-[14px] flex items-center justify-center text-3xl font-bold text-amber-300">
                {user.fullName ? user.fullName.charAt(0) : 'U'}
              </div>
            </div>
            <div className="absolute -bottom-1 -right-1 p-1 rounded-full bg-emerald-500 text-emerald-950 border-2 border-emerald-950" title="সক্রিয় একাউন্ট">
              <ShieldCheck className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* User Information */}
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <h2 className="text-xl font-bold text-white tracking-tight truncate">
                {user.fullName}
              </h2>
              <button
                onClick={() => {
                  setNewName(user.fullName);
                  setNewDistrict(user.district || '');
                  setNewUpazila(user.upazila || '');
                  setNewAddress(user.address || '');
                  setIsEditing(true);
                }}
                className="p-1 text-emerald-300 hover:text-white hover:bg-emerald-800/60 rounded-lg transition-colors"
                title="প্রোফাইল সম্পাদন করুন"
              >
                <Edit2 className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 mt-2 text-xs text-emerald-200/80">
              <span className="flex items-center gap-1">
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                <span>{user.phone}</span>
              </span>

              <span className="flex items-center gap-1 font-mono text-[11px] bg-emerald-900/60 px-2 py-0.5 rounded-md border border-emerald-700/40">
                ID: {user.id}
              </span>
            </div>

            {(user.district || user.upazila || user.address) && (
              <div className="flex items-start justify-center sm:justify-start gap-1.5 mt-2 text-xs text-amber-300/90 bg-emerald-900/40 px-2.5 py-1.5 rounded-lg border border-emerald-700/30">
                <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <div className="truncate">
                  {user.district && (
                    <span className="font-semibold text-white">
                      {BANGLADESH_DISTRICTS.find(d => d.district === user.district || d.districtBn === user.district)?.districtBn || user.district}
                      {user.upazila ? `, ${user.upazila}` : ''}
                    </span>
                  )}
                  {user.address && <span className="block text-[11px] text-amber-200/80 truncate">{user.address}</span>}
                </div>
              </div>
            )}

            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 mt-2 text-[11px] text-emerald-300/70">
              <span>যোগদান: {formatBnDate(user.createdAt)}</span>
              <span>•</span>
              <span className="text-emerald-400 font-semibold">স্ট্যাটাস: সক্রিয়</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Navigation & Support Section */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-5 shadow-lg space-y-3">
        <h3 className="text-sm font-bold text-white mb-2">সেটিংস ও প্রয়োজনীয় লিংক</h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {onNavigateTab && (
            <>
              <button
                onClick={() => onNavigateTab('prayer_journey')}
                className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-emerald-700/60 transition-colors text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-emerald-950 border border-emerald-800 text-emerald-400">
                    <Calendar className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-white block">সালাত জার্নি ও আত্মিক উন্নতি</span>
                    <span className="text-[10px] text-slate-400">ধারাবাহিকতা, অ্যানালিটিক্স ও হিস্ট্রি</span>
                  </div>
                </div>
              </button>

              <button
                onClick={() => onNavigateTab('support')}
                className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-emerald-700/60 transition-colors text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-teal-950 border border-teal-800 text-teal-400">
                    <Award className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-white block">হেল্প ও সাপোর্ট</span>
                    <span className="text-[10px] text-slate-400">প্রশ্নোত্তর ও সরাসরি সহায়তা</span>
                  </div>
                </div>
              </button>

              <button
                onClick={() => onNavigateTab('merchant')}
                className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-amber-700/60 transition-colors text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-amber-950 border border-amber-800 text-amber-400">
                    <Store className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-white block flex items-center gap-1.5">
                      মার্চেন্ট পোর্টাল (দোকানদার)
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono">PORTAL</span>
                    </span>
                    <span className="text-[10px] text-slate-400">টোকেন রিডেম্পশন, সেলস ও হিস্ট্রি</span>
                  </div>
                </div>
              </button>

              <button
                onClick={() => onNavigateTab('admin')}
                className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-rose-700/60 transition-colors text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-rose-950 border border-rose-800 text-rose-400">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-white block flex items-center gap-1.5">
                      এডমিন ড্যাশবোর্ড
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 font-mono">ADMIN</span>
                    </span>
                    <span className="text-[10px] text-slate-400">শপ স্ট্যাটাস, কিউআর কোড ও টেলিমেট্রি</span>
                  </div>
                </div>
              </button>
            </>
          )}
        </div>

        {/* Legal links */}
        {onOpenLegal && (
          <div className="pt-2 border-t border-slate-800/60 flex flex-wrap items-center justify-center gap-4 text-xs text-slate-400">
            <button
              onClick={() => onOpenLegal('privacy')}
              className="hover:text-emerald-400 transition-colors"
            >
              গোপনীয়তা নীতি
            </button>
            <span>•</span>
            <button
              onClick={() => onOpenLegal('terms')}
              className="hover:text-emerald-400 transition-colors"
            >
              শর্তাবলী
            </button>
            <span>•</span>
            <button
              onClick={() => onOpenLegal('about')}
              className="hover:text-emerald-400 transition-colors"
            >
              অ্যাপ সম্পর্কে
            </button>
          </div>
        )}
      </div>

      {/* Logout Action */}
      <div className="pt-2">
        <button
          onClick={onLogout}
          className="w-full py-3.5 px-4 rounded-2xl bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/60 text-rose-200 font-semibold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>লগআউট করুন</span>
        </button>
      </div>

      {/* Edit Profile Modal */}
      <AnimatePresence>
        {isEditing && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-950 border border-emerald-700/60 rounded-3xl p-6 max-w-sm w-full shadow-2xl"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base font-bold text-white">প্রোফাইল সম্পাদন</h3>
                <button
                  onClick={() => setIsEditing(false)}
                  className="p-1 text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveProfile} className="space-y-4">
                <div>
                  <label className="block text-xs text-slate-300 mb-1.5">আপনার নাম</label>
                  <input
                    type="text"
                    required
                    value={newName}
                    onChange={e => setNewName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-slate-300 mb-1.5">জেলা</label>
                    <select
                      value={newDistrict}
                      onChange={e => {
                        setNewDistrict(e.target.value);
                        setNewUpazila('');
                      }}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="">জেলা নির্বাচন করুন</option>
                      {BANGLADESH_DISTRICTS.map(d => (
                        <option key={d.district} value={d.district}>{d.districtBn}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-300 mb-1.5">উপজেলা</label>
                    <select
                      disabled={!newDistrict}
                      value={newUpazila}
                      onChange={e => setNewUpazila(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <option value="">{!newDistrict ? 'প্রথমে জেলা নির্বাচন করুন' : 'উপজেলা নির্বাচন করুন'}</option>
                      {newDistrict && BANGLADESH_DISTRICTS.find(d => d.district === newDistrict)?.upazilas.map(u => (
                        <option key={u} value={u}>{u}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-slate-300 mb-1.5">পূর্ণ ঠিকানা</label>
                  <textarea
                    rows={2}
                    value={newAddress}
                    onChange={e => setNewAddress(e.target.value)}
                    placeholder="গ্রাম/মহল্লা, রোড, বাড়ি/হোল্ডিং বা বিস্তারিত ঠিকানা লিখুন"
                    className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    disabled={savingProfile}
                    className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors disabled:opacity-50"
                  >
                    {savingProfile ? 'সংরক্ষণ...' : 'সংরক্ষণ করুন'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
