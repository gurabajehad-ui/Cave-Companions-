import React, { useState } from 'react';
import { Bell } from 'lucide-react';
import { prayerReminderService, PrayerReminderSettings } from '../services/prayerReminderService';

interface PrayerReminderCardProps {
  onShowToast: (type: 'success' | 'error' | 'info', title: string, msg: string) => void;
  userDistrict?: string;
  onDistrictChange?: (district: string) => void;
}

export const PrayerReminderCard: React.FC<PrayerReminderCardProps> = ({
  onShowToast
}) => {
  const [settings, setSettings] = useState<PrayerReminderSettings>(prayerReminderService.getSettings());

  const handleToggleMaster = async (enabled: boolean) => {
    if (enabled) {
      const perm = await prayerReminderService.requestNotificationPermission();
      if (perm !== 'granted') {
        onShowToast('error', 'অনুমতি মেলেনি', 'ব্রাউজার সেটিংসে গিয়ে নোটিফিকেশন অনুমতি চালু করুন।');
      }
    }
    const updated = prayerReminderService.saveSettings({ enabled });
    setSettings(updated);
    if (enabled) {
      onShowToast('success', 'রিমাইন্ডার চালু', 'সালাতের ওয়াক্ত শুরু হওয়ার নোটিফিকেশন চালু হয়েছে।');
    } else {
      onShowToast('info', 'রিমাইন্ডার বন্ধ', 'সালাতের নোটিফিকেশন সাময়িকভাবে বন্ধ করা হলো।');
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between gap-3 text-white shadow-md">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
          <Bell className="w-5 h-5" />
        </div>
        <span className="text-sm font-bold text-white sm:text-base">
          সালাতের রিমাইন্ডার সেট করুন
        </span>
      </div>

      <button
        type="button"
        onClick={() => handleToggleMaster(!settings.enabled)}
        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none shrink-0 ${
          settings.enabled ? 'bg-emerald-500' : 'bg-slate-700'
        }`}
        title={settings.enabled ? 'নোটিফিকেশন চালু আছে' : 'নোটিফিকেশন বন্ধ আছে'}
      >
        <span
          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
            settings.enabled ? 'translate-x-6' : 'translate-x-1'
          }`}
        />
      </button>
    </div>
  );
};
