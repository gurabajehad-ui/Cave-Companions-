import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, CheckCircle2, Clock, MapPin, QrCode, ShieldCheck, Loader2 } from 'lucide-react';
import { PrayerInfo, TodayPrayerStatus } from '../types';
import { PRAYERS_CONFIG, getTodayPrayerOrder, formatBnTime, formatBnDate, toBnNumber, getHijriDate } from '../data/prayerConfig';

interface TodayPrayerStatusModalProps {
  status: TodayPrayerStatus | null;
  userGender?: string;
  onClose: () => void;
  onOpenScan: (prayer: PrayerInfo) => Promise<void> | void;
}

export const TodayPrayerStatusModal: React.FC<TodayPrayerStatusModalProps> = ({
  status,
  userGender,
  onClose,
  onOpenScan
}) => {
  const [loadingPrayer, setLoadingPrayer] = useState<string | null>(null);

  if (!status) return null;
  const isFemale = userGender?.toLowerCase() === 'female';
  const hijri = getHijriDate(status.date);

  const handleActionClick = async (prayerInfo: PrayerInfo) => {
    if (loadingPrayer) return; // Prevent duplicate clicks
    if (isFemale || prayerInfo.type === 'jumuah') {
      setLoadingPrayer(prayerInfo.type);
      try {
        await onOpenScan(prayerInfo);
      } finally {
        setLoadingPrayer(null);
        onClose();
      }
    } else {
      onClose();
      onOpenScan(prayerInfo);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="w-full max-w-lg bg-slate-950 border border-emerald-700/60 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="bg-emerald-950 px-5 py-4 border-b border-emerald-800/80 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white leading-tight">
              আজকের সালাতের বিবরণী (Today's Status)
            </h2>
            <div className="flex items-center gap-1.5 mt-0.5 flex-wrap text-xs text-emerald-300 font-medium">
              <span>{formatBnDate(status.date)}</span>
              {hijri.bengali && (
                <>
                  <span className="text-emerald-500/60">•</span>
                  <span className="text-amber-300 font-semibold">{hijri.bengali}</span>
                </>
              )}
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-emerald-900/60 text-emerald-200 hover:text-white hover:bg-emerald-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Summary Banner */}
        <div className="p-4 bg-gradient-to-r from-emerald-900/80 to-teal-950/80 border-b border-emerald-800/60 flex items-center justify-between">
          <div>
            <p className="text-xs text-emerald-300 font-semibold uppercase tracking-wider">সারসংক্ষেপ</p>
            <p className="text-lg font-bold text-white">
              {status.summaryText}
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-800/60 border border-emerald-600/40 flex items-center justify-center text-amber-300 font-bold text-base">
            {toBnNumber(status.completedCount)}/{toBnNumber(5)}
          </div>
        </div>

        {/* 5 Prayers List */}
        <div className="p-5 overflow-y-auto space-y-3 flex-1">
          {getTodayPrayerOrder(status.date).map(prayerType => {
            const prayerInfo = PRAYERS_CONFIG[prayerType];
            const prayerState = status.prayers[prayerType];
            const isCompleted = prayerState?.completed;
            const att = prayerState?.attendance;

            return (
              <div
                key={prayerType}
                className={`p-4 rounded-2xl border transition-all ${
                  isCompleted
                    ? 'bg-emerald-950/70 border-emerald-600/50'
                    : 'bg-slate-900/80 border-slate-800'
                }`}
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center text-xs font-bold ${
                        isCompleted
                          ? 'bg-emerald-800 text-amber-300 border border-emerald-500/40'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {isCompleted ? <CheckCircle2 className="w-5 h-5 text-emerald-400" /> : <Clock className="w-4 h-4" />}
                    </div>

                    <div>
                      <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                        <span>{prayerInfo.nameBn}</span>
                        <span className="text-xs text-slate-400 font-normal">({prayerInfo.nameEn})</span>
                      </h4>
                      <p className="text-[11px] text-slate-400">{prayerInfo.timeWindowBn}</p>
                    </div>
                  </div>

                  <div>
                    {isCompleted ? (
                      <span className="text-xs font-bold text-emerald-400 px-2.5 py-1 rounded-full bg-emerald-900/60 border border-emerald-700/50">
                        যাচাইকৃত ✅
                      </span>
                    ) : (
                      <button
                        onClick={() => handleActionClick(prayerInfo)}
                        disabled={loadingPrayer === prayerType}
                        className={`px-3 py-1.5 rounded-lg ${loadingPrayer === prayerType ? 'bg-emerald-800 cursor-not-allowed' : 'bg-emerald-600 hover:bg-emerald-500'} text-white text-xs font-semibold flex items-center gap-1 transition-colors`}
                      >
                        {loadingPrayer === prayerType ? (
                          <>
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            <span>প্রসেসিং...</span>
                          </>
                        ) : isFemale || prayerType === 'jumuah' ? (
                          <>
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>সম্পন্ন করুন</span>
                          </>
                        ) : (
                          <>
                            <QrCode className="w-3.5 h-3.5" />
                            <span>স্ক্যান</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>

                {isCompleted && att && (
                  <div className="mt-3 pt-2.5 border-t border-emerald-800/40 text-[11px] text-emerald-200/90 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-1 text-emerald-300">
                      <MapPin className="w-3.5 h-3.5 text-amber-400" />
                      <span>{att.mosqueName}</span>
                    </div>
                    <div className="font-mono text-emerald-400/80">
                      সময়: {formatBnTime(att.verifiedAt)}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="bg-slate-900 px-5 py-3 border-t border-slate-800 text-center">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors"
          >
            বন্ধ করুন
          </button>
        </div>
      </motion.div>
    </div>
  );
};
