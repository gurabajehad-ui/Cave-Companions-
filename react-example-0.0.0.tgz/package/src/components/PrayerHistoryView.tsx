import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Calendar,
  CheckCircle2,
  XCircle,
  ArrowLeft,
  MapPin,
  History,
  Sparkles
} from 'lucide-react';
import { api } from '../services/api';
import { DailyPrayerHistoryGroup, PrayerAttendance } from '../types';
import { toBnNumber, formatBnTime, PRAYERS_CONFIG } from '../data/prayerConfig';

interface PrayerHistoryViewProps {
  onBack?: () => void;
  onShowToast: (type: 'success' | 'error' | 'info', title: string, msg: string) => void;
}

export const PrayerHistoryView: React.FC<PrayerHistoryViewProps> = ({ onBack, onShowToast }) => {
  const [days, setDays] = useState<DailyPrayerHistoryGroup[]>([]);
  const [individualHistory, setIndividualHistory] = useState<PrayerAttendance[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [filterPrayer, setFilterPrayer] = useState<'all' | 'fajr' | 'dhuhr' | 'jumuah' | 'asr' | 'maghrib' | 'isha'>('all');

  const fetchHistory = useCallback(async () => {
    try {
      setLoading(true);
      setErrorMsg(null);
      // Fetch both grouped days (for statistics) and individual records in parallel
      const [groupedRes, individualRes] = await Promise.all([
        api.getGroupedPrayerHistory(45),
        api.getPrayerHistory(100)
      ]);
      setDays(groupedRes.days || []);
      setIndividualHistory(individualRes.history || []);
    } catch (err: any) {
      console.error('Failed to load prayer history:', err);
      setErrorMsg(err?.message || 'নামাজের ইতিহাস লোড করা সম্ভব হয়নি।');
      onShowToast('error', 'ত্রুটি', err?.message || 'নামাজের ইতিহাস লোড করা যায়নি।');
    } finally {
      setLoading(false);
    }
  }, [onShowToast]);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  const filteredHistory = individualHistory.filter(item => {
    if (filterPrayer === 'all') return true;
    return item.prayerType.toLowerCase() === filterPrayer.toLowerCase();
  });

  const totalVerifiedAllTime = days.reduce((sum, d) => sum + d.totalCompleted, 0);
  const totalGoldDays = days.filter(d => d.earnedToken === 'GOLD').length;
  const totalSilverDays = days.filter(d => d.earnedToken === 'SILVER').length;
  const totalBronzeDays = days.filter(d => d.earnedToken === 'BRONZE').length;

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-6 pb-24 text-slate-100">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {onBack && (
            <button
              onClick={onBack}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <div>
            <h1 className="text-xl font-bold text-white flex items-center gap-2">
              <Calendar className="w-5 h-5 text-emerald-400" />
              দৈনিক সালাত ট্র্যাকার ও ইতিহাস
            </h1>
            <p className="text-xs text-slate-400">প্রতিদিনের ৫ ওয়াক্ত জামাত ও টোকেন সারাংশ</p>
          </div>
        </div>
      </div>

      {/* Summary Stat Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-3 text-center">
          <span className="text-[11px] text-slate-400 font-semibold block mb-1">মোট জামাত</span>
          <span className="text-xl font-black text-emerald-400">{toBnNumber(totalVerifiedAllTime)}</span>
        </div>
        <div className="bg-slate-900/80 border border-amber-800/40 rounded-2xl p-3 text-center">
          <span className="text-[11px] text-amber-300 font-semibold block mb-1">🥇 গোল্ড দিন</span>
          <span className="text-xl font-black text-amber-400">{toBnNumber(totalGoldDays)}</span>
        </div>
        <div className="bg-slate-900/80 border border-slate-700/50 rounded-2xl p-3 text-center">
          <span className="text-[11px] text-slate-300 font-semibold block mb-1">🥈 সিলভার দিন</span>
          <span className="text-xl font-black text-slate-200">{toBnNumber(totalSilverDays)}</span>
        </div>
        <div className="bg-slate-900/80 border border-amber-900/40 rounded-2xl p-3 text-center">
          <span className="text-[11px] text-amber-600 font-semibold block mb-1">🥉 ব্রোঞ্জ দিন</span>
          <span className="text-xl font-black text-amber-500">{toBnNumber(totalBronzeDays)}</span>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 text-xs">
        {[
          { id: 'all', label: 'সকল ওয়াক্ত' },
          { id: 'fajr', label: 'ফজর' },
          { id: 'dhuhr', label: 'যোহর' },
          { id: 'jumuah', label: 'জুমআ' },
          { id: 'asr', label: 'আসর' },
          { id: 'maghrib', label: 'মাগরিব' },
          { id: 'isha', label: 'এশা' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setFilterPrayer(tab.id as any)}
            className={`px-3.5 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
              filterPrayer === tab.id
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Recent Prayer History Layout Section */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-5 shadow-lg space-y-4">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-emerald-950 text-amber-300 border border-emerald-800">
              <History className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white">সাম্প্রতিক নামাজের ইতিহাস (History)</h3>
          </div>
          <span className="text-[11px] text-slate-400">{toBnNumber(filteredHistory.length)} টি রেকর্ড</span>
        </div>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="animate-pulse bg-slate-950/60 border border-slate-800 rounded-2xl p-4 h-16" />
            ))}
          </div>
        ) : errorMsg ? (
          <div className="text-center py-12 bg-slate-950/40 border border-rose-900/50 rounded-3xl p-6">
            <p className="text-sm font-semibold text-rose-300 mb-3">{errorMsg}</p>
            <button
              onClick={() => fetchHistory()}
              className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-2xl text-xs font-bold transition-all cursor-pointer shadow-lg"
            >
              পুনরায় চেষ্টা করুন
            </button>
          </div>
        ) : filteredHistory.length === 0 ? (
          <div className="text-center py-16 bg-slate-950/30 border border-dashed border-slate-800 rounded-3xl p-6">
            <Calendar className="w-10 h-10 mx-auto text-slate-600 mb-2" />
            <h3 className="text-sm font-bold text-slate-300">কোনো রেকর্ড পাওয়া যায়নি</h3>
            <p className="text-xs text-slate-500 mt-1">মসজিদে জামাতে সালাত ভেরিফাই করলে আপনার নামাজের ইতিহাস এখানে যুক্ত হবে।</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
            <AnimatePresence mode="popLayout">
              {filteredHistory.map(item => {
                const prayerInfo = PRAYERS_CONFIG[item.prayerType];
                return (
                  <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-emerald-700/50 transition-all flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-emerald-950 border border-emerald-700/30 flex items-center justify-center text-emerald-400 shrink-0">
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-bold text-white text-sm">
                            {prayerInfo ? prayerInfo.nameBn : item.prayerType}
                          </span>
                          <span className="text-[10px] text-slate-400 font-semibold">({item.date})</span>
                        </div>
                        <p className="text-[11px] text-emerald-300/80 flex items-center gap-1 mt-1 min-w-0">
                          <MapPin className="w-3 h-3 text-amber-400 shrink-0" />
                          <span className="truncate">{item.mosqueName}</span>
                        </p>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="text-[11px] font-semibold text-slate-300 block mb-0.5">
                        {formatBnTime(item.verifiedAt)}
                      </span>
                      <span className="text-[9px] text-emerald-400 font-bold tracking-wide">
                        যাচাইকৃত
                      </span>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
};
