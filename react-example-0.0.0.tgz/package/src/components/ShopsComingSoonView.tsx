import React from 'react';
import { Store, Lock, Sparkles, ShoppingBag, BookOpen, Utensils, Shirt } from 'lucide-react';

export const ShopsComingSoonView: React.FC = () => {
  const sampleCategories = [
    { title: 'হালাল রেস্তোরাঁ ও ক্যাফে', icon: Utensils, discount: '১০-১৫% ছাড়', desc: 'নিবন্ধিত হালাল ফুড পার্টনার' },
    { title: 'ইসলামিক বই ও লাইব্রেরি', icon: BookOpen, discount: '১২-২০% ছাড়', desc: 'কুরআন, হাদিস ও ইসলামী সাহিত্য' },
    { title: 'পাঞ্জাবি ও সুন্নতি পোশাক', icon: Shirt, discount: '১৫-২৫% ছাড়', desc: 'প্রিমিয়াম ক্লদিং ও আতর' },
    { title: 'দৈনন্দিন মুদি ও সুপারশপ', icon: ShoppingBag, discount: '৫-১০% ক্যাশব্যাক', desc: 'হালাল গ্রোসারি চেইন' }
  ];

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-6 pb-24 text-slate-100">
      {/* Banner */}
      <div className="bg-gradient-to-br from-teal-950 via-slate-900 to-emerald-950 border border-teal-500/40 rounded-3xl p-6 shadow-xl relative overflow-hidden text-center sm:text-left">
        <div className="flex flex-col sm:flex-row items-center gap-5 relative z-10">
          <div className="w-16 h-16 rounded-2xl bg-teal-500/20 border border-teal-400/40 flex items-center justify-center text-3xl shrink-0">
            🏬
          </div>

          <div className="flex-1">
            <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/40 text-[10px] font-bold uppercase tracking-wider mb-1.5">
              <Lock className="w-3 h-3" />
              <span>Phase 6 Architecture (শীঘ্রই আসছে)</span>
            </div>
            <h2 className="text-xl font-extrabold text-white">পার্টনার দোকানসমূহ (Partner Shops)</h2>
            <p className="text-xs text-teal-200/80 mt-1 leading-relaxed">
              আপনার অর্জিত গোল্ড, সিলভার ও ব্রোঞ্জ টোকেন দিয়ে পার্টনার শপসমূহে বিশেষ অফার ও রিওয়ার্ড উপভোগ করুন।
            </p>
          </div>
        </div>
      </div>

      {/* Category previews */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {sampleCategories.map((cat, idx) => {
          const Icon = cat.icon;
          return (
            <div
              key={idx}
              className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-teal-700/50 transition-all flex items-start gap-4"
            >
              <div className="w-12 h-12 rounded-2xl bg-teal-950 border border-teal-700/50 flex items-center justify-center text-teal-400 shrink-0">
                <Icon className="w-6 h-6" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1">
                  <h3 className="text-sm font-bold text-white truncate">{cat.title}</h3>
                  <span className="text-[10px] font-bold text-amber-300 px-2 py-0.5 rounded bg-amber-950/60 border border-amber-600/40">
                    {cat.discount}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">{cat.desc}</p>
                <div className="mt-3 flex items-center gap-1.5 text-[11px] text-teal-400/80">
                  <Sparkles className="w-3 h-3" />
                  <span>আসন্ন মার্চেন্ট কিউআর রিডেম্পশন</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Merchant Partnership Callout */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 text-center space-y-3">
        <h3 className="text-sm font-bold text-white">আপনি কি কোনো ব্যবসা বা দোকানের মালিক?</h3>
        <p className="text-xs text-slate-400 max-w-md mx-auto">
          কেভ কম্প্যানিয়ন্স পার্টনার নেটওয়ার্কে যুক্ত হয়ে নিয়মিত জামাতে নামাজ আদায়কারী মুসাল্লীদের জন্য বিশেষ ছাড় অফার করুন।
        </p>
        <button
          onClick={() => alert('মার্চেন্ট অনবোর্ডিং খুব শীঘ্রই উন্মুক্ত করা হবে, ইনশাআল্লাহ!')}
          className="px-4 py-2 rounded-xl bg-teal-800 hover:bg-teal-700 text-teal-100 text-xs font-semibold transition-colors"
        >
          মার্চেন্ট হিসেবে যুক্ত হতে আগ্রহ প্রকাশ করুন
        </button>
      </div>
    </div>
  );
};
