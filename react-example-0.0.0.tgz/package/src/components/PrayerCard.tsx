import React from 'react';
import { motion } from 'motion/react';
import { QrCode, CheckCircle2, Clock, MapPin, Check, Sunrise, Sun, CloudSun, Sunset, Moon, Loader2 } from 'lucide-react';
import { PrayerInfo, PrayerStatusItem } from '../types';
import { formatBnTime } from '../data/prayerConfig';

interface PrayerCardProps {
  prayer: PrayerInfo;
  status: PrayerStatusItem;
  userGender?: string;
  onOpenScan: (prayer: PrayerInfo) => void;
  isVerifying?: boolean;
}

export const PrayerCard: React.FC<PrayerCardProps> = ({ prayer, status, userGender = 'male', onOpenScan, isVerifying = false }) => {
  const isCompleted = status.completed;
  const attendance = status.attendance;
  const isFemale = userGender.toLowerCase() === 'female';

  // Icon selector
  const getIcon = () => {
    switch (prayer.type) {
      case 'fajr':
        return <Sunrise className="w-5 h-5" />;
      case 'dhuhr':
      case 'jumuah':
        return <Sun className="w-5 h-5" />;
      case 'asr':
        return <CloudSun className="w-5 h-5" />;
      case 'maghrib':
        return <Sunset className="w-5 h-5" />;
      case 'isha':
        return <Moon className="w-5 h-5" />;
      default:
        return <Clock className="w-5 h-5" />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-2xl p-4 sm:p-5 border transition-all duration-300 ${
        isCompleted
          ? 'bg-emerald-50 dark:bg-emerald-950/80 border-emerald-200 dark:border-emerald-500/50 text-emerald-950 dark:text-white shadow-xs dark:shadow-md dark:shadow-emerald-950/40'
          : 'bg-white dark:bg-slate-900/80 hover:bg-slate-50 dark:hover:bg-slate-900/95 border-slate-200/80 dark:border-slate-800 text-slate-800 dark:text-slate-100 shadow-xs'
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        {/* Left: Prayer Icon & Titles */}
        <div className="flex items-start gap-3">
          <div
            className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border ${
              isCompleted
                ? 'bg-emerald-600 dark:bg-emerald-800/80 border-emerald-400/40 text-amber-300'
                : 'bg-emerald-50 dark:bg-slate-800 border-emerald-100 dark:border-slate-700 text-emerald-600 dark:text-emerald-400'
            }`}
          >
            {getIcon()}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h3 className={`text-base sm:text-lg font-bold leading-tight ${
                isCompleted 
                  ? 'text-emerald-950 dark:text-white' 
                  : 'text-slate-800 dark:text-white'
              }`}>
                {prayer.nameBn}
              </h3>
              <span className={`text-xs font-medium ${
                isCompleted ? 'text-emerald-700/80 dark:text-emerald-300/80' : 'text-slate-500 dark:text-slate-400'
              }`}>({prayer.nameEn})</span>
              <span className={`text-xs font-arabic ${
                isCompleted ? 'text-emerald-800 dark:text-emerald-400/80' : 'text-emerald-600 dark:text-emerald-400/80'
              }`}>{prayer.nameAr}</span>
            </div>

            <div className={`flex items-center gap-1.5 text-xs mt-1 ${
              isCompleted ? 'text-emerald-800/80 dark:text-emerald-200/80' : 'text-slate-600 dark:text-slate-300/80'
            }`}>
              <Clock className={`w-3.5 h-3.5 shrink-0 ${isCompleted ? 'text-emerald-700 dark:text-emerald-400' : 'text-emerald-600 dark:text-emerald-400'}`} />
              <span>ওয়াক্ত: {prayer.timeWindowBn}</span>
            </div>

            <div className={`text-[11px] mt-0.5 ${
              isCompleted ? 'text-emerald-700/80 dark:text-emerald-400/80' : 'text-slate-500 dark:text-slate-400'
            }`}>
              <span>{prayer.rakats}</span>
            </div>
          </div>
        </div>

        {/* Right: Status Pill */}
        <div>
          {isCompleted ? (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 dark:bg-emerald-900/80 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-600/50 shadow-xs">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>জামাতে সম্পন্ন</span>
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 dark:bg-amber-400 animate-ping"></span>
              <span>অসমাপ্ত</span>
            </span>
          )}
        </div>
      </div>

      {/* If Completed: Mosque info & Verification metadata */}
      {isCompleted && attendance && (
        <div className="mt-3 pt-3 border-t border-emerald-100 dark:border-emerald-800/40 text-xs text-emerald-900/90 dark:text-emerald-200/90 flex flex-wrap items-center justify-between gap-2 bg-emerald-100/40 dark:bg-emerald-900/30 -mx-4 sm:-mx-5 -mb-4 sm:-mb-5 px-4 sm:px-5 py-2.5 rounded-b-2xl">
          <div className="flex items-center gap-1.5 text-emerald-800 dark:text-emerald-300">
            <MapPin className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400 shrink-0" />
            <span className="font-medium truncate max-w-[200px] sm:max-w-xs">
              {attendance.mosqueName}
            </span>
          </div>

          <div className="text-[11px] text-emerald-700/80 dark:text-emerald-300/70 font-mono">
            যাচাই: {formatBnTime(attendance.verifiedAt)}
          </div>
        </div>
      )}

      {/* If Not Completed: Action Button */}
      {!isCompleted && (
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between gap-3">
          <p className="text-xs text-slate-500 dark:text-slate-400 hidden sm:block">
            {isFemale || prayer.type === 'jumuah' ? 'বর্তমান ওয়াক্তের সালাত সম্পন্ন হলে ক্লিক করুন' : 'মসজিদের QR কোড স্ক্যান করে উপস্থিতি নিশ্চিত করুন'}
          </p>

          <button
            onClick={() => !isVerifying && onOpenScan(prayer)}
            disabled={isVerifying}
            className={`w-full sm:w-auto ml-auto px-4 py-2.5 rounded-xl text-white font-bold text-xs shadow-md dark:shadow-emerald-950/40 flex items-center justify-center gap-2 transition-all ${
              isVerifying
                ? 'bg-emerald-800 cursor-not-allowed opacity-80'
                : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 hover:scale-[1.02] active:scale-[0.98]'
            }`}
          >
            {isVerifying ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-amber-300" />
                <span>প্রসেসিং...</span>
              </>
            ) : isFemale || prayer.type === 'jumuah' ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-amber-300" />
                <span>নামাজ সম্পন্ন করুন</span>
              </>
            ) : (
              <>
                <QrCode className="w-4 h-4 text-amber-300" />
                <span>আলহামদুলিল্লাহ সালাত সম্পন্ন করেছি</span>
              </>
            )}
          </button>
        </div>
      )}
    </motion.div>
  );
};
