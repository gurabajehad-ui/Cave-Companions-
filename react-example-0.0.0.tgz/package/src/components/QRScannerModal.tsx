import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';
import { Html5Qrcode } from 'html5-qrcode';
import confetti from 'canvas-confetti';
import { X, Camera, AlertCircle } from 'lucide-react';
import { Mosque, PrayerInfo } from '../types';
import { api } from '../services/api';

interface QRScannerModalProps {
  prayer: PrayerInfo;
  onClose: () => void;
  onSuccess: (attendanceData: any) => void;
  onErrorToast: (title: string, msg: string) => void;
  mosques: Mosque[];
}

export const QRScannerModal: React.FC<QRScannerModalProps> = ({
  prayer,
  onClose,
  onSuccess,
  onErrorToast,
  mosques
}) => {
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);

  const html5QrCodeRef = useRef<Html5Qrcode | null>(null);
  const scannerContainerId = 'cave-companions-qr-reader';

  const startCamera = async () => {
    setCameraError(null);

    try {
      if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
        await html5QrCodeRef.current.stop();
        html5QrCodeRef.current.clear();
      }

      const html5QrCode = new Html5Qrcode(scannerContainerId);
      html5QrCodeRef.current = html5QrCode;

      const config = {
        fps: 10,
        qrbox: { width: 250, height: 250 },
        aspectRatio: 1.0
      };

      await html5QrCode.start(
        { facingMode: 'environment' },
        config,
        (decodedText) => {
          handleQrDetected(decodedText);
        },
        (errorMessage) => {
          // Ignore frame scan errors
        }
      );
    } catch (err: any) {
      console.warn('Camera start error:', err);
      setCameraError(
        'ক্যামেরা চালু করা সম্ভব হয়নি (পারমিশন দেওয়া নেই অথবা ডিভাইস সাপোর্ট করছে না)।'
      );
    }
  };

  // Initialize camera scanner
  useEffect(() => {
    startCamera();

    return () => {
      if (html5QrCodeRef.current) {
        try {
          if (html5QrCodeRef.current.isScanning) {
            html5QrCodeRef.current.stop().then(() => {
              html5QrCodeRef.current?.clear();
            }).catch(console.warn);
          } else {
            html5QrCodeRef.current.clear();
          }
        } catch (e) {
          console.warn('Error clearing scanner', e);
        }
      }
    };
  }, []);

  const stopCameraSafely = async () => {
    if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
      try {
        await html5QrCodeRef.current.stop();
        html5QrCodeRef.current.clear();
      } catch (e) {
        console.warn('Error stopping camera:', e);
      }
    }
  };

  const handleQrDetected = async (qrData: string) => {
    if (isVerifying) return;
    setIsVerifying(true);

    // Stop camera while processing
    await stopCameraSafely();

    let lat: number | undefined;
    let lng: number | undefined;

    try {
      if (navigator.geolocation) {
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject, {
            timeout: 7000,
            enableHighAccuracy: true
          });
        });
        lat = position.coords.latitude;
        lng = position.coords.longitude;
      }
    } catch (e) {
      console.warn('Geolocation acquisition failed or denied:', e);
    }

    try {
      const result = await api.verifyPrayerQr(prayer.type, qrData, lat, lng);

      // Trigger Confetti Celebration!
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#10b981', '#fbbf24', '#34d399', '#ffffff']
        });
      } catch (e) {}

      onSuccess(result);
    } catch (err: any) {
      const errorMsg = err.message || 'QR ভেরিফিকেশন ব্যর্থ হয়েছে।';
      onErrorToast('ভেরিফিকেশন ব্যর্থ', errorMsg);
      setIsVerifying(false);
      // Restart camera so user can try again
      setTimeout(() => {
        startCamera();
      }, 500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="w-full max-w-lg bg-slate-950 border border-emerald-700/60 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]"
      >
        {/* Header */}
        <div className="bg-emerald-950 px-5 py-4 border-b border-emerald-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-800 flex items-center justify-center text-amber-300">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white leading-tight">
                মসজিদ QR স্ক্যানার — {prayer.nameBn} ({prayer.nameEn})
              </h2>
              <p className="text-xs text-emerald-300/80 mt-0.5">
                মসজিদের QR কোডটি ফ্রেমের মাঝে রাখুন
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-emerald-900/60 text-emerald-200 hover:text-white hover:bg-emerald-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-5 overflow-y-auto space-y-4">
          <div className="space-y-3">
            <div className="relative rounded-2xl overflow-hidden bg-black border-2 border-emerald-500/50 shadow-inner flex flex-col items-center justify-center min-h-[280px]">
              {/* Html5Qrcode target container */}
              <div id={scannerContainerId} className="w-full h-full min-h-[280px]"></div>

              {isVerifying && (
                <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center text-center p-4 z-20">
                  <div className="w-12 h-12 border-4 border-emerald-400 border-t-transparent rounded-full animate-spin mb-3"></div>
                  <p className="text-sm font-bold text-white">QR যাচাই করা হচ্ছে...</p>
                  <p className="text-xs text-emerald-300/80 mt-1">মসজিদের উপস্থিতি ডেটাবেজে সংরক্ষিত হচ্ছে</p>
                </div>
              )}
            </div>

            {cameraError && (
              <div className="p-3 rounded-xl bg-amber-950/60 border border-amber-500/40 text-amber-200 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold">{cameraError}</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-900 px-5 py-3 border-t border-slate-800 text-[11px] text-slate-400 text-center">
          প্রতি ওয়াক্তে শুধুমাত্র একবার মসজিদে জামাতের উপস্থিতি রেকর্ড করা যাবে।
        </div>
      </motion.div>
    </div>
  );
};
