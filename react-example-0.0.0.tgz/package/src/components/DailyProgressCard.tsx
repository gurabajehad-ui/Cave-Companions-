import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, Award, Sparkles, Calendar, ChevronRight, TrendingUp, Flame, BarChart3 } from 'lucide-react';
import { toBnNumber, formatBnDate, getHijriDate } from '../data/prayerConfig';
import { api } from '../services/api';
import { JourneyTeaser } from '../types';

interface DailyProgressCardProps {
  completedCount: number;
  totalPrayers?: number;
  dateStr: string;
  onViewDetails: () => void;
  onOpenMosques: () => void;
  onOpenJourney?: () => void;
}

export const DailyProgressCard: React.FC<DailyProgressCardProps> = ({
  completedCount,
  totalPrayers = 5,
  dateStr,
  onViewDetails,
  onOpenMosques,
  onOpenJourney
}) => {
  const percentage = Math.round((completedCount / totalPrayers) * 100);
  const hijri = getHijriDate(dateStr);

  const [teaser, setTeaser] = useState<JourneyTeaser | null>(null);

  useEffect(() => {
    let isMounted = true;
    api.getJourneySummary().then(res => {
      if (isMounted && res?.teaser) {
        setTeaser(res.teaser);
      }
    }).catch(err => {
      console.warn('Failed to load journey teaser:', err);
    });
    return () => {
      isMounted = false;
    };
  }, [completedCount]);

  // Determine token qualification state
  let tierBadge = null;
  if (completedCount === 5) {
    tierBadge = {
      name: 'আজ অর্জিত: গোল্ড টোকেন',
      color: 'from-amber-400 to-yellow-500 text-amber-950 border-amber-300',
      icon: '🥇'
    };
  } else if (completedCount === 4) {
    tierBadge = {
      name: 'আজ অর্জিত: সিলভার টোকেন',
      color: 'from-slate-200 to-slate-400 text-slate-950 border-slate-200',
      icon: '🥈'
    };
  } else if (completedCount === 3) {
    tierBadge = {
      name: 'আজ অর্জিত: ব্রোঞ্জ টোকেন',
      color: 'from-amber-700 to-amber-800 text-amber-100 border-amber-600',
      icon: '🥉'
    };
  }

  return (
    <div className="bg-gradient-to-br from-emerald-900 via-emerald-950 to-teal-950 border border-emerald-700/60 rounded-3xl p-5 shadow-xl relative overflow-hidden text-white space-y-4">
      {/* Decorative glow */}
      <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none"></div>

      {/* Header date and info */}
      <div className="flex items-center justify-between gap-2 relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-xl bg-emerald-800/80 text-amber-300 border border-emerald-600/40 shrink-0">
            <Calendar className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[11px] uppercase tracking-wider text-emerald-300/80 font-bold block">
                আজকের দিনপঞ্জি
              </span>
              {hijri.bengali && (
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-800/80 border border-emerald-600/50 text-amber-300 font-semibold shadow-xs">
                  {hijri.bengali}
                </span>
              )}
            </div>
            <div className="text-xs font-semibold text-emerald-100 flex items-center gap-1.5 flex-wrap mt-0.5">
              <span>{formatBnDate(dateStr)}</span>
            </div>
          </div>
        </div>

        <button
          onClick={onViewDetails}
          className="text-xs text-amber-300 hover:text-amber-200 flex items-center gap-0.5 font-medium px-2 py-1 rounded-lg bg-emerald-900/60 border border-emerald-700/40 hover:bg-emerald-800 transition-all shrink-0 cursor-pointer"
        >
          <span>বিস্তারিত</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* COMPACT SALAH JOURNEY & GROWTH CLICKABLE SECTION */}
      {onOpenJourney && (
        <button
          onClick={onOpenJourney}
          className="w-full text-left p-3 rounded-2xl bg-slate-950/60 hover:bg-slate-950/80 border border-emerald-600/40 hover:border-amber-400/60 transition-all flex items-center justify-between gap-2.5 relative z-10 group cursor-pointer shadow-md"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-800 to-teal-900 border border-emerald-500/40 flex items-center justify-center text-amber-300 shrink-0 group-hover:scale-105 transition-transform">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-white group-hover:text-amber-300 transition-colors">
                  {teaser?.headline || 'আমার সালাত জার্নি'}
                </span>
                {teaser?.badgeText && (
                  <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-emerald-800/80 text-emerald-200 font-bold border border-emerald-600/40">
                    {teaser.badgeText}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-emerald-200/90 truncate font-medium mt-0.5">
                {teaser ? `${teaser.primaryStat} • ${teaser.secondaryStat}` : 'আপনার ধারাবাহিকতা ও বিশ্লেষণ দেখুন'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 text-xs text-amber-300 font-semibold shrink-0 group-hover:translate-x-0.5 transition-transform">
            <span className="hidden sm:inline">জার্নি দেখুন</span>
            <ChevronRight className="w-4 h-4" />
          </div>
        </button>
      )}

      {/* Main Counter Headline */}
      <div className="relative z-10">
        <div className="flex items-baseline gap-2">
          <span className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            আজ {toBnNumber(completedCount)}/{toBnNumber(totalPrayers)}
          </span>
          <span className="text-sm sm:text-base font-semibold text-emerald-200">
            ওয়াক্ত জামাতে নামাজ সম্পন্ন
          </span>
        </div>
        <p className="text-xs text-emerald-300/80 mt-1">
          {completedCount === 5
            ? 'মাশাআল্লাহ! আপনি আজকের সবকটি নামাজ জামাতে সম্পন্ন করেছেন!'
            : completedCount > 0
            ? `বাকি রয়েছে ${toBnNumber(totalPrayers - completedCount)} ওয়াক্ত নামাজ। মসজিদে এসে জামাতে অংশ নিন।`
            : 'আজকের প্রথম নামাজের জামাতে উপস্থিত হতে প্রস্তুত থাকুন।'}
        </p>
      </div>

      {/* 5-Step Segmented Bar */}
      <div className="grid grid-cols-5 gap-2 relative z-10">
        {[1, 2, 3, 4, 5].map(step => {
          const isDone = step <= completedCount;
          return (
            <div key={step} className="flex flex-col items-center gap-1.5">
              <div
                className={`w-full h-2 rounded-full transition-all duration-500 ${
                  isDone
                    ? 'bg-gradient-to-r from-amber-400 to-amber-500 shadow-[0_0_8px_rgba(251,191,36,0.6)]'
                    : 'bg-emerald-950/80 border border-emerald-800/80'
                }`}
              />
              <span className={`text-[10px] font-bold ${isDone ? 'text-amber-300' : 'text-emerald-500/60'}`}>
                {toBnNumber(step)}
              </span>
            </div>
          );
        })}
      </div>

      {/* Phase 4 Tier Teaser Pill */}
      <div className="pt-3 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-2 relative z-10">
        {tierBadge ? (
          <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-gradient-to-r ${tierBadge.color} border shadow-sm`}>
            <span>{tierBadge.icon}</span>
            <span>{tierBadge.name}</span>
          </div>
        ) : (
          <div className="inline-flex items-center gap-1.5 text-xs text-amber-300/90 font-medium">
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span>টোকেন অর্জনে ন্যূনতম ৩ ওয়াক্ত জামাত প্রয়োজন</span>
          </div>
        )}

        <button
          onClick={onOpenMosques}
          className="text-xs text-emerald-300 hover:text-white underline underline-offset-2 transition-colors ml-auto cursor-pointer"
        >
          মসজিদ খুঁজুন
        </button>
      </div>
    </div>
  );
};
