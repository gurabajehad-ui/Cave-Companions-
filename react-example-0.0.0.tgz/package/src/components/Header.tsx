import React from 'react';
import { Landmark, HelpCircle, Bell, Moon, Sun, Monitor, MapPin } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { AppLogo } from './AppLogo';

interface HeaderProps {
  onOpenMosques: () => void;
  onOpenHelp: () => void;
  onOpenNotifications?: () => void;
  unreadNotificationsCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenMosques,
  onOpenHelp,
  onOpenNotifications,
  unreadNotificationsCount = 0
}) => {
  const { theme, setTheme } = useTheme();
  const { user } = useAuth();

  const handleCycleTheme = () => {
    if (theme === 'light') setTheme('dark');
    else if (theme === 'dark') setTheme('system');
    else setTheme('light');
  };

  return (
    <header className="w-full px-3 sm:px-4 pt-3 pb-1 max-w-4xl mx-auto">
      {/* Top Header Card */}
      <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl bg-[#031d16] border border-emerald-800/60 shadow-xl px-3 sm:px-5 py-3 sm:py-3.5 text-white">
        
        {/* Background Decorative Mosque Architecture Silhouette */}
        <div className="absolute right-0 top-0 bottom-0 w-80 pointer-events-none opacity-20 text-emerald-500 overflow-hidden flex items-end justify-end">
          <svg
            viewBox="0 0 400 120"
            className="w-full h-full object-cover"
            fill="currentColor"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Mosque Domes & Minarets */}
            <path d="M 280 120 L 280 70 C 280 50 300 35 320 35 C 340 35 360 50 360 70 L 360 120 Z" opacity="0.6" />
            <path d="M 317 35 L 320 10 L 323 35 Z" opacity="0.9" />
            <circle cx="320" cy="8" r="2.5" />
            {/* Main Center Dome */}
            <path d="M 220 120 L 220 65 C 220 40 245 20 270 20 C 295 20 320 40 320 65 L 320 120 Z" opacity="0.8" />
            <path d="M 268 20 L 270 2 L 272 20 Z" opacity="1" />
            <circle cx="270" cy="2" r="3" />
            {/* Left Minaret */}
            <rect x="180" y="45" width="14" height="75" rx="2" opacity="0.7" />
            <path d="M 177 45 L 187 25 L 197 45 Z" opacity="0.9" />
            <circle cx="187" cy="22" r="2" />
            {/* Right Minaret */}
            <rect x="375" y="40" width="16" height="80" rx="2" opacity="0.7" />
            <path d="M 372 40 L 383 18 L 394 40 Z" opacity="0.9" />
            <circle cx="383" cy="15" r="2.5" />
            {/* Subtle Kaaba silhouette on far right */}
            <rect x="388" y="75" width="25" height="45" rx="1" opacity="0.5" />
          </svg>
        </div>

        {/* Header Content Flexbox */}
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-3 sm:gap-4">
          
          {/* Top/Left Row on Mobile: Logo & Brand Name + (4 Action buttons on small screens) */}
          <div className="w-full md:w-auto flex items-center justify-between md:justify-start gap-3">
            {/* Logo and Brand Name */}
            <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
              {/* Circular Logo Badge with Golden Ring Border */}
              <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-full ring-2 ring-amber-500/50 border-2 border-[#031d16] overflow-hidden bg-slate-950 flex items-center justify-center shrink-0 shadow-md">
                <AppLogo className="w-full h-full rounded-full object-cover" />
              </div>

              {/* Stacked Brand Name */}
              <div className="flex flex-col select-none leading-none">
                <span className="text-base sm:text-lg font-black tracking-tight text-white">
                  Cave
                </span>
                <span className="text-base sm:text-lg font-black tracking-tight text-white mt-0.5">
                  Companions
                </span>
              </div>
            </div>

            {/* Mobile Action Buttons (Visible only on small screens < md) */}
            <div className="flex md:hidden items-center gap-1.5 shrink-0">
              {onOpenNotifications && (
                <button
                  onClick={onOpenNotifications}
                  className="relative w-8 h-8 rounded-full bg-[#04241b]/90 hover:bg-emerald-900/90 border border-emerald-700/60 text-amber-400 flex items-center justify-center transition cursor-pointer active:scale-95 shadow-xs"
                  title="বিজ্ঞপ্তি সমূহ"
                >
                  <Bell className="w-3.5 h-3.5" />
                  {unreadNotificationsCount > 0 && (
                    <span className="absolute -top-1 -right-1 px-1 py-0.2 rounded-full text-[8px] font-bold bg-rose-500 text-white animate-pulse">
                      {unreadNotificationsCount}
                    </span>
                  )}
                </button>
              )}

              <button
                onClick={onOpenMosques}
                className="w-8 h-8 rounded-full bg-[#04241b]/90 hover:bg-emerald-900/90 border border-emerald-700/60 text-emerald-400 flex items-center justify-center transition cursor-pointer active:scale-95 shadow-xs"
                title="মসজিদ সমূহ"
              >
                <Landmark className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={onOpenHelp}
                className="w-8 h-8 rounded-full bg-[#04241b]/90 hover:bg-emerald-900/90 border border-emerald-700/60 text-amber-400 flex items-center justify-center transition cursor-pointer active:scale-95 shadow-xs"
                title="সাহায্য ও সাপোর্ট"
              >
                <HelpCircle className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={handleCycleTheme}
                className="w-8 h-8 rounded-full bg-[#04241b]/90 hover:bg-emerald-900/90 border border-emerald-700/60 text-amber-400 flex items-center justify-center transition cursor-pointer active:scale-95 shadow-xs"
                title={`থিম পরিবর্তন (বর্তমান: ${theme})`}
              >
                {theme === 'light' ? (
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                ) : theme === 'dark' ? (
                  <Moon className="w-3.5 h-3.5 text-amber-400" />
                ) : (
                  <Monitor className="w-3.5 h-3.5 text-emerald-400" />
                )}
              </button>
            </div>
          </div>

          {/* Center Column: Dua (Surah Al-Kahf 18:10) with Ornamental Divider */}
          <div className="flex flex-col items-center justify-center text-center px-1 sm:px-4 py-0.5 max-w-md mx-auto">
            <p className="text-[11px] sm:text-[13px] text-[#e6d5ba] font-medium leading-relaxed tracking-wide">
              আমাদের রব, আমাদেরকে অনুগ্রহ করুন
              <br />
              এবং আমাদের কাজকর্ম সঠিকভাবে
              <br />
              পরিচালনার ব্যবস্থা করে দিন
            </p>

            {/* Golden Ornamental Divider */}
            <div className="flex items-center justify-center gap-1.5 mt-1 opacity-80">
              <div className="w-8 sm:w-14 h-[1px] bg-gradient-to-r from-transparent via-amber-400/70 to-amber-300" />
              <div className="w-1.5 h-1.5 rotate-45 border border-amber-300 bg-amber-400/40" />
              <div className="w-8 sm:w-14 h-[1px] bg-gradient-to-l from-transparent via-amber-400/70 to-amber-300" />
            </div>
          </div>

          {/* Right Column: 4 Circular Action Buttons (Desktop & Tablet >= md) */}
          <div className="hidden md:flex items-center gap-2 shrink-0">
            {/* 1. Notification Bell */}
            {onOpenNotifications && (
              <button
                onClick={onOpenNotifications}
                className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#04241b]/90 hover:bg-emerald-900 border border-emerald-700/60 text-amber-400 flex items-center justify-center transition cursor-pointer active:scale-95 shadow-sm"
                title="বিজ্ঞপ্তি সমূহ"
              >
                <Bell className="w-4 h-4 text-amber-400" />
                {unreadNotificationsCount > 0 && (
                  <span className="absolute -top-1 -right-1 px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-rose-500 text-white animate-pulse">
                    {unreadNotificationsCount}
                  </span>
                )}
              </button>
            )}

            {/* 2. Registered Mosques */}
            <button
              onClick={onOpenMosques}
              className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#04241b]/90 hover:bg-emerald-900 border border-emerald-700/60 text-emerald-400 flex items-center justify-center transition cursor-pointer active:scale-95 shadow-sm"
              title="নিবন্ধিত মসজিদ সমূহ"
            >
              <Landmark className="w-4 h-4 text-emerald-400" />
            </button>

            {/* 3. Help & Support */}
            <button
              onClick={onOpenHelp}
              className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#04241b]/90 hover:bg-emerald-900 border border-emerald-700/60 text-amber-400 flex items-center justify-center transition cursor-pointer active:scale-95 shadow-sm"
              title="সাহায্য ও সাপোর্ট"
            >
              <HelpCircle className="w-4 h-4 text-amber-400" />
            </button>

            {/* 4. Moon / Theme Toggle */}
            <button
              onClick={handleCycleTheme}
              className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#04241b]/90 hover:bg-emerald-900 border border-emerald-700/60 text-amber-400 flex items-center justify-center transition cursor-pointer active:scale-95 shadow-sm"
              title={`থিম পরিবর্তন (বর্তমান: ${theme})`}
            >
              {theme === 'light' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : theme === 'dark' ? (
                <Moon className="w-4 h-4 text-amber-400" />
              ) : (
                <Monitor className="w-4 h-4 text-emerald-400" />
              )}
            </button>
          </div>

        </div>

        {/* User Greeting Strip seamlessly attached to Header */}
        {user && (
          <div className="relative z-10 mt-3 pt-2.5 border-t border-emerald-800/50 flex items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2 truncate">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
              <span className="text-emerald-200/90 font-medium truncate">
                আসসালামু আলাইকুম,{' '}
                <span className="text-amber-300 font-bold">
                  {user.fullName || 'সম্মানিত ভাই/বোন'}
                </span>
              </span>
            </div>

            {user.district && (
              <span className="text-[11px] text-emerald-300/90 bg-emerald-950/80 border border-emerald-800/60 px-2.5 py-0.5 rounded-full shrink-0 flex items-center gap-1 font-medium shadow-xs">
                <MapPin className="w-3 h-3 text-amber-400" />
                <span>{user.district}</span>
              </span>
            )}
          </div>
        )}
      </div>
    </header>
  );
};

