import { PrayerType } from '../types';
import { Coordinates, CalculationMethod, PrayerTimes as AdhanPrayerTimes, Madhab } from 'adhan';

export interface LocationCoords {
  latitude: number;
  longitude: number;
  locationName?: string;
  source: 'gps' | 'district' | 'default';
}

export interface CalculatedPrayerTime {
  type: PrayerType;
  nameBn: string;
  nameEn: string;
  startTime: Date; // Exact JavaScript Date for start of prayer
  reminderTime: Date; // Exactly 10 minutes before startTime
  formattedTimeBn: string; // e.g., "০৫:১০ AM"
  formattedReminderBn: string; // e.g., "০৫:০০ AM"
}

export type LocationPrayerTimes = Partial<Record<PrayerType, CalculatedPrayerTime>> & Record<string, CalculatedPrayerTime>;

// Default district coordinates in Bangladesh for fallback when GPS is disabled
export const DISTRICT_COORDINATES: Record<string, { lat: number; lng: number; nameBn: string }> = {
  'Dhaka': { lat: 23.8103, lng: 90.4125, nameBn: 'ঢাকা' },
  'Chattogram': { lat: 22.3569, lng: 91.7832, nameBn: 'চট্টগ্রাম' },
  'Sylhet': { lat: 24.8949, lng: 91.8687, nameBn: 'সিলেট' },
  'Rajshahi': { lat: 24.3745, lng: 88.6042, nameBn: 'রাজশাহী' },
  'Khulna': { lat: 22.8456, lng: 89.5403, nameBn: 'খুলনা' },
  'Barishal': { lat: 22.7010, lng: 90.3535, nameBn: 'বরিশাল' },
  'Rangpur': { lat: 25.7439, lng: 89.2752, nameBn: 'রংপুর' },
  'Mymensingh': { lat: 24.7471, lng: 90.4203, nameBn: 'ময়মনসিংহ' },
  'Cumilla': { lat: 23.4607, lng: 91.1809, nameBn: 'কুমিল্লা' },
  "Cox's Bazar": { lat: 21.4272, lng: 92.0058, nameBn: 'কক্সবাজার' },
  'Bogra': { lat: 24.8481, lng: 89.3730, nameBn: 'বগুড়া' },
  'Bogura': { lat: 24.8481, lng: 89.3730, nameBn: 'বগুড়া' },
  'Jashore': { lat: 23.1664, lng: 89.2081, nameBn: 'যশোর' },
  'Pabna': { lat: 24.0129, lng: 89.2530, nameBn: 'পাবনা' },
  'Noakhali': { lat: 22.8696, lng: 91.0993, nameBn: 'নোয়াখালী' },
  'Feni': { lat: 23.0159, lng: 91.3976, nameBn: 'ফেনী' },
  'Brahmanbaria': { lat: 23.9571, lng: 91.1119, nameBn: 'ব্রাহ্মণবাড়িয়া' },
  'Gazipur': { lat: 24.0023, lng: 90.4264, nameBn: 'গাজীপুর' },
  'Narayanganj': { lat: 23.6238, lng: 90.5000, nameBn: 'নারায়ণগঞ্জ' },
  'Tangail': { lat: 24.2513, lng: 89.9167, nameBn: 'টাঙ্গাইল' },
  'Kushtia': { lat: 23.9013, lng: 89.1204, nameBn: 'কুষ্টিয়া' },
  'Dinajpur': { lat: 25.6217, lng: 88.6354, nameBn: 'দিনাজপুর' },
  'Faridpur': { lat: 23.6071, lng: 89.8425, nameBn: 'ফরিদপুর' },
  'Kishoreganj': { lat: 24.4449, lng: 90.7766, nameBn: 'কিশোরগঞ্জ' }
};

const DEFAULT_COORDS: LocationCoords = {
  latitude: 23.8103,
  longitude: 90.4125,
  locationName: 'ঢাকা (ডিফল্ট)',
  source: 'default'
};

// Converts number to Bengali digits
function toBnDigits(numStr: string | number): string {
  const bnDigits: Record<string, string> = {
    '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
    '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯'
  };
  return String(numStr).replace(/\d/g, d => bnDigits[d] || d);
}

export function formatTimeBn(date: Date): string {
  let hours = date.getHours();
  const minutes = date.getMinutes();
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12;
  const hStr = hours < 10 ? `0${hours}` : `${hours}`;
  const mStr = minutes < 10 ? `0${minutes}` : `${minutes}`;
  return `${toBnDigits(hStr)}:${toBnDigits(mStr)} ${ampm}`;
}

/**
 * Astronomical solar calculation fallback for Prayer Times
 */
function calculateSolarPrayerTimes(lat: number, lng: number, date: Date = new Date()) {
  const d = new Date(date);
  d.setHours(12, 0, 0, 0);

  // Timezone offset in hours
  const tzOffsetHours = -d.getTimezoneOffset() / 60;

  // Day of year
  const startOfYear = new Date(d.getFullYear(), 0, 0);
  const diff = d.getTime() - startOfYear.getTime();
  const dayOfYear = Math.floor(diff / (1000 * 60 * 60 * 24));

  // Solar declination & Equation of Time (approximate)
  const b = (2 * Math.PI * (dayOfYear - 81)) / 364;
  const eqTime = 9.87 * Math.sin(2 * b) - 7.53 * Math.cos(b) - 1.5 * Math.sin(b); // minutes
  const declination = 23.45 * Math.sin((2 * Math.PI * (284 + dayOfYear)) / 365); // degrees

  const rad = (deg: number) => (deg * Math.PI) / 180;
  const deg = (rad: number) => (rad * 180) / Math.PI;

  const latRad = rad(lat);
  const declRad = rad(declination);

  // Solar Noon in local time
  const solarNoonMinutes = 720 - 4 * lng - eqTime + tzOffsetHours * 60;

  // Hour Angle helper
  const hourAngle = (angle: number) => {
    const angleRad = rad(angle);
    const cosHA = (Math.sin(angleRad) - Math.sin(latRad) * Math.sin(declRad)) / (Math.cos(latRad) * Math.cos(declRad));
    if (cosHA > 1) return 0;
    if (cosHA < -1) return 180;
    return deg(Math.acos(cosHA));
  };

  // Fajr: 18° below horizon
  const haFajr = hourAngle(-18);
  const fajrMin = solarNoonMinutes - (haFajr * 4);

  // Dhuhr: solar noon + 2 min safety margin
  const dhuhrMin = solarNoonMinutes + 2;

  // Asr: Shafi'i method (shadow factor = 1)
  const acot = (x: number) => Math.atan(1 / x);
  const asrAlt = deg(acot(1 + Math.tan(Math.abs(latRad - declRad))));
  const haAsr = hourAngle(asrAlt);
  const asrMin = solarNoonMinutes + (haAsr * 4);

  // Maghrib: 0.833° below horizon (sunset)
  const haMaghrib = hourAngle(-0.833);
  const maghribMin = solarNoonMinutes + (haMaghrib * 4);

  // Isha: 18° below horizon
  const haIsha = hourAngle(-18);
  const ishaMin = solarNoonMinutes + (haIsha * 4);

  const makeDate = (totalMinutes: number) => {
    const timeDate = new Date(date);
    const h = Math.floor(totalMinutes / 60);
    const m = Math.floor(totalMinutes % 60);
    timeDate.setHours(h, m, 0, 0);
    return timeDate;
  };

  return {
    fajr: makeDate(fajrMin),
    dhuhr: makeDate(dhuhrMin),
    asr: makeDate(asrMin),
    maghrib: makeDate(maghribMin),
    isha: makeDate(ishaMin)
  };
}

/**
 * Fetch or Calculate Prayer Times for Location
 */
export async function calculatePrayerTimes(
  coords: LocationCoords,
  date: Date = new Date()
): Promise<LocationPrayerTimes> {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();

  let timesMap: { fajr: Date; dhuhr: Date; asr: Date; maghrib: Date; isha: Date } | null = null;

  // Try fetching from Aladhan API for maximum regional accuracy (Method 1 = Karachi/BD standard)
  try {
    const dateStr = `${day}-${month}-${year}`;
    const response = await fetch(
      `https://api.aladhan.com/v1/timings/${dateStr}?latitude=${coords.latitude}&longitude=${coords.longitude}&method=1`
    );
    if (response.ok) {
      const data = await response.json();
      if (data && data.data && data.data.timings) {
        const t = data.data.timings;
        const parseApiTime = (timeStr: string) => {
          const [hh, mm] = timeStr.split(' ')[0].split(':').map(Number);
          const d = new Date(date);
          d.setHours(hh, mm, 0, 0);
          return d;
        };

        timesMap = {
          fajr: parseApiTime(t.Fajr),
          dhuhr: parseApiTime(t.Dhuhr),
          asr: parseApiTime(t.Asr),
          maghrib: parseApiTime(t.Maghrib),
          isha: parseApiTime(t.Isha)
        };
      }
    }
  } catch (err) {
    console.warn('Aladhan API request failed, using local solar calculation:', err);
  }

  // Fallback to offline solar astronomical calculation if API call fails or is offline
  if (!timesMap) {
    timesMap = calculateSolarPrayerTimes(coords.latitude, coords.longitude, date);
  }

  const namesBn: Record<PrayerType, string> = {
    fajr: 'ফজর',
    dhuhr: 'যোহর',
    jumuah: 'জুমআ',
    asr: 'আসর',
    maghrib: 'মাগরিব',
    isha: 'এশা'
  };

  const namesEn: Record<PrayerType, string> = {
    fajr: 'Fajr',
    dhuhr: 'Dhuhr',
    jumuah: "Jumu'ah",
    asr: 'Asr',
    maghrib: 'Maghrib',
    isha: 'Isha'
  };

  const prayers: PrayerType[] = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
  const result = {} as LocationPrayerTimes;

  prayers.forEach(p => {
    const startTime = timesMap![p];
    // Exactly 10 minutes before prayer start time
    const reminderTime = new Date(startTime.getTime() - 10 * 60 * 1000);

    result[p] = {
      type: p,
      nameBn: namesBn[p],
      nameEn: namesEn[p],
      startTime,
      reminderTime,
      formattedTimeBn: formatTimeBn(startTime),
      formattedReminderBn: formatTimeBn(reminderTime)
    };
  });

  // Calculate Jumu'ah for Friday (same start/reminder time as Dhuhr)
  const dhuhrTime = timesMap!.dhuhr;
  const jumuahReminder = new Date(dhuhrTime.getTime() - 10 * 60 * 1000);
  result['jumuah'] = {
    type: 'jumuah',
    nameBn: 'জুমআ',
    nameEn: "Jumu'ah",
    startTime: dhuhrTime,
    reminderTime: jumuahReminder,
    formattedTimeBn: formatTimeBn(dhuhrTime),
    formattedReminderBn: formatTimeBn(jumuahReminder)
  };

  return result;
}

/**
 * Get device GPS coordinates or user's selected district coordinates
 */
export function getSavedOrGpsLocation(userDistrict?: string): Promise<LocationCoords> {
  return new Promise(resolve => {
    // 1. Try Browser GPS
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        position => {
          resolve({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            locationName: 'আপনার জিপিএস লোকেশন',
            source: 'gps'
          });
        },
        error => {
          console.warn('GPS location permission denied or unavailable, checking district:', error.message);
          resolve(getDistrictLocationFallback(userDistrict));
        },
        { timeout: 6000, maximumAge: 300000 }
      );
    } else {
      resolve(getDistrictLocationFallback(userDistrict));
    }
  });
}

function getDistrictLocationFallback(userDistrict?: string): LocationCoords {
  if (userDistrict) {
    const matchKey = Object.keys(DISTRICT_COORDINATES).find(
      key => key.toLowerCase() === userDistrict.toLowerCase() ||
             DISTRICT_COORDINATES[key].nameBn === userDistrict
    );
    if (matchKey) {
      const item = DISTRICT_COORDINATES[matchKey];
      return {
        latitude: item.lat,
        longitude: item.lng,
        locationName: item.nameBn,
        source: 'district'
      };
    }
  }

  // Check saved district in localStorage
  const storedDistrict = localStorage.getItem('user_district');
  if (storedDistrict && DISTRICT_COORDINATES[storedDistrict]) {
    const item = DISTRICT_COORDINATES[storedDistrict];
    return {
      latitude: item.lat,
      longitude: item.lng,
      locationName: item.nameBn,
      source: 'district'
    };
  }

  return DEFAULT_COORDS;
}

export function getDhakaDateClient(now?: Date): Date {
  const target = now || new Date();
  try {
    const formatter = new Intl.DateTimeFormat('en-US', {
      timeZone: 'Asia/Dhaka',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    });
    const parts = formatter.formatToParts(target);
    const map: Record<string, string> = {};
    for (const part of parts) {
      map[part.type] = part.value;
    }
    return new Date(
      `${map.year}-${map.month}-${map.day}T${map.hour}:${map.minute}:${map.second}`
    );
  } catch (e) {
    return target;
  }
}

export function getDhakaDateStringClient(dateInput?: string | Date): string {
  const target = dateInput ? (typeof dateInput === 'string' ? new Date(dateInput) : dateInput) : new Date();
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Dhaka',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  });
  return formatter.format(target);
}

export function isFridayClient(dateInput?: string | Date): boolean {
  if (dateInput) {
    if (typeof dateInput === 'string') {
      const match = dateInput.match(/^(\d{4})-(\d{2})-(\d{2})/);
      if (match) {
        const y = parseInt(match[1], 10);
        const m = parseInt(match[2], 10) - 1;
        const d = parseInt(match[3], 10);
        const dt = new Date(Date.UTC(y, m, d, 12, 0, 0));
        return dt.getUTCDay() === 5;
      }
    } else if (dateInput instanceof Date && !isNaN(dateInput.getTime())) {
      try {
        const formatter = new Intl.DateTimeFormat('en-US', {
          timeZone: 'Asia/Dhaka',
          weekday: 'short'
        });
        return formatter.format(dateInput) === 'Fri';
      } catch (e) {
        return dateInput.getDay() === 5;
      }
    }
  }
  const dhakaStr = getDhakaDateStringClient();
  return isFridayClient(dhakaStr);
}

/**
 * Returns the Canonical Operational Prayer Date (YYYY-MM-DD) on the client side.
 * For midnight-crossing prayer windows (Isha prayed between 00:00 and Fajr start):
 * maps to the previous calendar day's prayer cycle.
 */
export function getCanonicalPrayerDateClient(
  prayerType: PrayerType | string,
  customTime?: Date | string,
  lat?: number,
  lng?: number
): string {
  const nowUtc = customTime ? (typeof customTime === 'string' ? new Date(customTime) : customTime) : new Date();
  const dhakaDate = getDhakaDateClient(nowUtc);
  const coordinates = new Coordinates(lat || 23.8103, lng || 90.4125);
  const params = CalculationMethod.Karachi();
  params.madhab = Madhab.Hanafi;

  const pt = new AdhanPrayerTimes(coordinates, dhakaDate, params);

  if (prayerType === 'isha') {
    if (nowUtc < pt.fajr) {
      const prevDay = new Date(dhakaDate.getTime() - 24 * 60 * 60 * 1000);
      return getDhakaDateStringClient(prevDay);
    }
  }

  return getDhakaDateStringClient(nowUtc);
}

/**
 * Returns the currently active operational prayer date on client.
 */
export function getOperationalPrayerDateClient(
  customTime?: Date | string,
  lat?: number,
  lng?: number
): string {
  const nowUtc = customTime ? (typeof customTime === 'string' ? new Date(customTime) : customTime) : new Date();
  const dhakaDate = getDhakaDateClient(nowUtc);
  const coordinates = new Coordinates(lat || 23.8103, lng || 90.4125);
  const params = CalculationMethod.Karachi();
  params.madhab = Madhab.Hanafi;

  const pt = new AdhanPrayerTimes(coordinates, dhakaDate, params);

  if (nowUtc < pt.fajr) {
    const prevDay = new Date(dhakaDate.getTime() - 24 * 60 * 60 * 1000);
    return getDhakaDateStringClient(prevDay);
  }
  return getDhakaDateStringClient(nowUtc);
}

/**
 * Formats the Islamic Hijri date string on the client.
 */
export function getHijriDateStringClient(dateInput?: string | Date): string {
  const target = dateInput ? (typeof dateInput === 'string' ? new Date(dateInput) : dateInput) : new Date();
  try {
    const formatter = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', {
      timeZone: 'Asia/Dhaka',
      year: 'numeric',
      month: 'numeric',
      day: 'numeric'
    });
    return formatter.format(target);
  } catch (e) {
    return '';
  }
}

export function isClientPrayerTimeValidOffline(
  prayerType: string,
  lat?: number,
  lng?: number,
  gender?: string,
  customTime?: Date
): { valid: boolean; reason?: string } {
  const nowUtc = customTime || new Date();
  const dhakaDate = getDhakaDateClient(nowUtc);
  const dhakaIsFriday = isFridayClient(nowUtc);

  // Friday Rule Validation:
  if (dhakaIsFriday && prayerType === 'dhuhr') {
    return {
      valid: false,
      reason: 'আজ শুক্রবার, জোহর-এর পরিবর্তে জুমআ সালাত যাচাই করুন।'
    };
  }

  if (!dhakaIsFriday && prayerType === 'jumuah') {
    return {
      valid: false,
      reason: 'জুমআ সালাত শুধুমাত্র শুক্রবারেই প্রযোজ্য। অনুগ্রহ করে যোহর সালাত যাচাই করুন।'
    };
  }

  // Default to Dhaka coordinates if not provided
  const coordinates = new Coordinates(lat || 23.8103, lng || 90.4125);
  const params = CalculationMethod.Karachi(); // Hanafi
  params.madhab = Madhab.Hanafi; // Hanafi for Asr

  const pt = new AdhanPrayerTimes(coordinates, dhakaDate, params);

  // Next and previous day for seamless boundary calculation
  const prevDay = new Date(dhakaDate.getTime() - 24 * 60 * 60 * 1000);
  const ptPrev = new AdhanPrayerTimes(coordinates, prevDay, params);

  const nextDay = new Date(dhakaDate.getTime() + 24 * 60 * 60 * 1000);
  const ptNext = new AdhanPrayerTimes(coordinates, nextDay, params);

  // If currently early morning before Fajr, the active Isha window is yesterday's Isha until today's Fajr
  let ishaStart = pt.isha;
  let ishaEnd = ptNext.fajr;
  if (nowUtc < pt.fajr) {
    ishaStart = ptPrev.isha;
    ishaEnd = pt.fajr;
  }

  // Create windows
  const times = {
    fajr: { start: pt.fajr, end: pt.sunrise },
    dhuhr: { start: pt.dhuhr, end: pt.asr },
    jumuah: { start: pt.dhuhr, end: pt.asr },
    asr: { start: pt.asr, end: pt.maghrib },
    maghrib: { start: pt.maghrib, end: pt.isha },
    isha: { start: ishaStart, end: ishaEnd }
  };

  const window = times[prayerType as keyof typeof times];
  if (!window) {
    return { valid: false, reason: 'অবৈধ ওয়াক্ত' };
  }

  // Grace period before / after. 5 mins buffer
  const bufferMs = 5 * 60 * 1000;
  const validStart = new Date(window.start.getTime() - bufferMs);
  const validEnd = new Date(window.end.getTime() + bufferMs);

  if (nowUtc >= validStart && nowUtc <= validEnd) {
    return { valid: true };
  } else {
    if (nowUtc < validStart) {
      const isFemale = (gender || '').toLowerCase() === 'female';
      const isJumuah = prayerType === 'jumuah';
      const prayerLabel = isJumuah ? 'জুমআ সালাতের' : 'এই ওয়াক্তের';
      const reason = isFemale || isJumuah
        ? `এখনও ${prayerLabel} সময় হয়নি। সময় হলে সালাত সম্পন্ন করুন।`
        : `নামাজের সময় এখনও হয়নি। সময় হলে স্ক্যান করুন।`;
      return { valid: false, reason };
    } else {
      return { valid: false, reason: 'এই সালাতের সময় শেষ হয়ে গেছে। এখন আর Present করা যাবে না।' };
    }
  }
}
