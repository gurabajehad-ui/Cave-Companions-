import { PrayerType } from '../types';
import { getTodayPrayerOrder } from '../data/prayerConfig';
import {
  calculatePrayerTimes,
  getSavedOrGpsLocation,
  LocationCoords,
  LocationPrayerTimes
} from './prayerTimeService';

export interface PrayerReminderSettings {
  enabled: boolean;
  soundEnabled?: boolean;
  reminderMinutesBefore?: number;
  prayers: Record<PrayerType, boolean>;
  userDistrict?: string;
  locationCoords?: LocationCoords | null;
}

const STORAGE_KEY = 'prayer_reminder_settings';

const DEFAULT_SETTINGS: PrayerReminderSettings = {
  enabled: true,
  soundEnabled: false,
  reminderMinutesBefore: 0,
  prayers: {
    fajr: true,
    dhuhr: true,
    jumuah: true,
    asr: true,
    maghrib: true,
    isha: true
  }
};

class PrayerReminderService {
  private settings: PrayerReminderSettings;
  private timerId: any = null;
  private currentPrayerTimes: LocationPrayerTimes | null = null;
  private currentLocation: LocationCoords | null = null;
  private onInAppReminderCallback: ((prayerType: PrayerType, nameBn: string, startTimeStr: string) => void) | null = null;

  constructor() {
    this.settings = this.loadSettings();
    this.initServiceWorker();
  }

  public loadSettings(): PrayerReminderSettings {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
      }
    } catch (e) {
      console.error('Failed to parse prayer reminder settings:', e);
    }
    return DEFAULT_SETTINGS;
  }

  public saveSettings(newSettings: Partial<PrayerReminderSettings>): PrayerReminderSettings {
    this.settings = { ...this.settings, ...newSettings };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.settings));
    } catch (e) {
      console.error('Failed to save prayer reminder settings:', e);
    }
    this.updateLocationAndTimes();
    return this.settings;
  }

  public getSettings(): PrayerReminderSettings {
    return { ...this.settings };
  }

  public setInAppReminderCallback(cb: (prayerType: PrayerType, nameBn: string, startTimeStr: string) => void) {
    this.onInAppReminderCallback = cb;
  }

  private async initServiceWorker() {
    if ('serviceWorker' in navigator) {
      try {
        await navigator.serviceWorker.register('/sw.js');
      } catch (e) {
        console.warn('Service worker registration failed:', e);
      }
    }
  }

  public async requestNotificationPermission(): Promise<NotificationPermission> {
    if (!('Notification' in window)) {
      console.warn('Browser does not support desktop notifications');
      return 'denied';
    }
    try {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        this.initServiceWorker();
      }
      return permission;
    } catch (e) {
      console.error('Error requesting notification permission:', e);
      return 'denied';
    }
  }

  public getNotificationPermission(): NotificationPermission {
    if (!('Notification' in window)) return 'denied';
    return Notification.permission;
  }

  /**
   * Start background scheduler that checks prayer times every 30 seconds
   */
  public async startScheduler() {
    this.stopScheduler();
    await this.updateLocationAndTimes();

    // Check every 30 seconds for 10-min prayer reminders
    this.timerId = setInterval(() => {
      this.checkAndTriggerReminders();
    }, 30000);

    // Initial check right away
    this.checkAndTriggerReminders();
  }

  public stopScheduler() {
    if (this.timerId) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
  }

  public async updateLocationAndTimes(userDistrict?: string): Promise<{ location: LocationCoords; times: LocationPrayerTimes }> {
    const coords = await getSavedOrGpsLocation(userDistrict || this.settings.userDistrict);
    this.currentLocation = coords;
    const times = await calculatePrayerTimes(coords, new Date());
    this.currentPrayerTimes = times;
    return { location: coords, times };
  }

  public getCurrentLocationAndTimes(): { location: LocationCoords | null; times: LocationPrayerTimes | null } {
    return {
      location: this.currentLocation,
      times: this.currentPrayerTimes
    };
  }

  /**
   * Main check function that fires notifications right when prayer time starts
   */
  private checkAndTriggerReminders() {
    if (!this.settings.enabled || !this.currentPrayerTimes) return;

    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const prayers: PrayerType[] = getTodayPrayerOrder(now);

    prayers.forEach(prayer => {
      // Check if user enabled reminder for this specific prayer (if jumuah, check dhuhr preference)
      const isEnabled = prayer === 'jumuah' ? (this.settings.prayers['dhuhr'] ?? true) : this.settings.prayers[prayer];
      if (!isEnabled) return;

      const info = this.currentPrayerTimes![prayer];
      if (!info) return;

      // Check if already notified today
      const notifiedKey = `prayer_notified_${prayer}_${todayStr}`;
      if (localStorage.getItem(notifiedKey)) return;

      // Check if prayer start time has arrived (within [0, 5] minutes of start time)
      const diffMs = now.getTime() - info.startTime.getTime();
      const diffMinutes = diffMs / (1000 * 60);

      // Trigger if current time is within 0 to 5 minutes after prayer start time
      if (diffMinutes >= 0 && diffMinutes <= 5) {
        // Mark as notified today
        localStorage.setItem(notifiedKey, 'true');

        // Trigger Notification
        this.triggerReminderNotification(info);
      }
    });
  }

  public triggerReminderNotification(info: { type: PrayerType; nameBn: string; nameEn: string; startTime: Date; formattedTimeBn: string }) {
    const title = `🕌 ${info.nameBn} সালাতের ওয়াক্ত শুরু হয়েছে`;
    const locationStr = this.currentLocation?.locationName ? ` (${this.currentLocation.locationName})` : '';
    const body = `আপনার লোকেশন${locationStr} অনুযায়ী এখন ${info.nameBn} সালাতের ওয়াক্ত শুরু হয়েছে (${info.formattedTimeBn})। সালাত আদায় করে নিন।`;

    // 1. Send System Push Notification via Browser (Silent / system vibration without audio chimes)
    if ('Notification' in window && Notification.permission === 'granted') {
      try {
        if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
          navigator.serviceWorker.ready.then(reg => {
            const swOptions: any = {
              body,
              icon: '/app_icon.jpg',
              badge: '/app_icon.jpg',
              silent: true,
              tag: `prayer-reminder-${info.type}`,
              renotify: true
            };
            reg.showNotification(title, swOptions);
          });
        } else {
          new Notification(title, {
            body,
            icon: '/app_icon.jpg',
            silent: true
          });
        }
      } catch (e) {
        console.error('Browser push notification error:', e);
      }
    }

    // 2. Trigger In-App UI Toast Callback
    if (this.onInAppReminderCallback) {
      this.onInAppReminderCallback(info.type, info.nameBn, info.formattedTimeBn);
    }
  }

  /**
   * Sound has been disabled as per user preference (silent notifications only)
   */
  public playChimeSound() {
    // Silent mode - no sound needed
  }

  /**
   * Send immediate test reminder for verification
   */
  public testReminder(): boolean {
    const testInfo = {
      type: 'dhuhr' as PrayerType,
      nameBn: 'যোহর',
      nameEn: 'Dhuhr',
      startTime: new Date(),
      formattedTimeBn: '১২:১৫ PM'
    };

    this.triggerReminderNotification(testInfo);
    return true;
  }
}

export const prayerReminderService = new PrayerReminderService();
