import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from './context/AuthContext';
import { ActiveTab, Mosque, PrayerInfo, TodayPrayerStatus } from './types';
import { api } from './services/api';
import { PRAYERS_CONFIG, getTodayPrayerOrder, HADITHS } from './data/prayerConfig';

// Components
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { SplashScreen } from './components/SplashScreen';
import { AuthScreen } from './components/AuthScreen';
import { DailyProgressCard } from './components/DailyProgressCard';
import { PrayerCard } from './components/PrayerCard';
import { QRScannerModal } from './components/QRScannerModal';
import { MosqueDirectoryModal } from './components/MosqueDirectoryModal';
import { TodayPrayerStatusModal } from './components/TodayPrayerStatusModal';
import { ProfileView } from './components/ProfileView';
import { MyTokenView } from './components/MyTokenView';
import { ShopsView } from './components/ShopsView';
import { MerchantPortalView } from './components/MerchantPortalView';
import { NotificationsView } from './components/NotificationsView';
import { SalahJourneyView } from './components/SalahJourneyView';
import { SupportView } from './components/SupportView';
import { CaveMarketView } from './components/CaveMarketView';
import AdBanner from './components/AdBanner';
import { AdminDashboardView } from './components/AdminDashboardView';
import { LegalModal } from './components/LegalModals';
import { HelpSupportModal } from './components/HelpSupportModal';
import { ToastContainer, ToastMessage } from './components/Toast';
import { prayerReminderService } from './services/prayerReminderService';
import { offlineSyncService } from './services/offlineSyncService';
import confetti from 'canvas-confetti';

import { Sparkles, BookOpen, Landmark, RefreshCw, CloudUpload, Wifi, WifiOff, AlertTriangle } from 'lucide-react';

export default function App() {
  const { user, isLoading, logout, refreshUser } = useAuth();

  // Navigation & Screen states
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);

  // Modals
  const [activeScanningPrayer, setActiveScanningPrayer] = useState<PrayerInfo | null>(null);
  const [showMosqueModal, setShowMosqueModal] = useState<boolean>(false);
  const [showHelpModal, setShowHelpModal] = useState<boolean>(false);
  const [showTodayStatusModal, setShowTodayStatusModal] = useState<boolean>(false);
  const [legalModalType, setLegalModalType] = useState<'privacy' | 'terms' | 'about' | null>(null);

  // Notifications State
  const [unreadNotificationsCount, setUnreadNotificationsCount] = useState<number>(0);
  const [actionLoadingPrayerType, setActionLoadingPrayerType] = useState<string | null>(null);

  // Offline Sync State
  const [pendingOfflineItems, setPendingOfflineItems] = useState(offlineSyncService.getPendingCheckIns());
  const [isSyncingOffline, setIsSyncingOffline] = useState(offlineSyncService.getIsSyncing());
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);

  // Prayer state
  const [todayStatus, setTodayStatus] = useState<TodayPrayerStatus | null>(null);
  const [mosques, setMosques] = useState<Mosque[]>([]);
  const [loadingPrayers, setLoadingPrayers] = useState<boolean>(true);
  const [randomHadithIndex, setRandomHadithIndex] = useState<number>(0);
  const [nasihaList, setNasihaList] = useState<any[]>([]);

  // Toast notifications
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = useCallback((type: 'success' | 'error' | 'info' | 'warning', title: string, message: string) => {
    const id = Date.now().toString() + Math.random().toString().slice(2, 6);
    setToasts(prev => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4500);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  // Fetch notification count
  const fetchNotificationCount = useCallback(async () => {
    if (!user) return;
    const token = localStorage.getItem('cave_companions_auth_token');
    if (!token) return;
    try {
      const data = await api.getNotifications(true);
      setUnreadNotificationsCount(data.unreadCount || 0);
    } catch (err: any) {
      const isOffline = typeof navigator !== 'undefined' && !navigator.onLine;
      const isNetworkOrTimeout = isOffline || err.isNetworkError || err.isTimeout || (err.message && (
        err.message.includes('নেটওয়ার্ক') || 
        err.message.includes('সংযোগ') || 
        err.message.includes('fetch') || 
        err.message.includes('Failed to fetch') ||
        err.message.includes('NetworkError') ||
        err.message.includes('AbortError') ||
        err.message.includes('timeout')
      ));
      if (isNetworkOrTimeout) {
        console.warn('Network issue fetching notification count:', err);
        return;
      }
      if (err.message && (err.message.includes('লগইন') || err.message.includes('সেশন') || err.message.includes('UNAUTHORIZED') || err.message.includes('INVALID_TOKEN'))) {
        logout();
        return;
      }
      console.error('Failed to fetch notification count:', err);
    }
  }, [user, logout]);

  // Fetch today's prayer status
  const fetchTodayStatus = useCallback(async () => {
    if (!user) return;
    const token = localStorage.getItem('cave_companions_auth_token');
    if (!token) return;
    try {
      setLoadingPrayers(true);
      const data = await api.getTodayPrayers();
      setTodayStatus(data);
    } catch (err: any) {
      const isOffline = typeof navigator !== 'undefined' && !navigator.onLine;
      const isNetworkOrTimeout = isOffline || err.isNetworkError || err.isTimeout || (err.message && (
        err.message.includes('নেটওয়ার্ক') || 
        err.message.includes('সংযোগ') || 
        err.message.includes('fetch') || 
        err.message.includes('Failed to fetch') ||
        err.message.includes('NetworkError') ||
        err.message.includes('AbortError') ||
        err.message.includes('timeout')
      ));
      if (isNetworkOrTimeout) {
        console.warn('Network issue fetching today prayers:', err);
        return;
      }
      if (err.message && (err.message.includes('লগইন') || err.message.includes('সেশন') || err.message.includes('UNAUTHORIZED') || err.message.includes('INVALID_TOKEN'))) {
        logout();
        return;
      }
      console.error('Failed to fetch today prayers:', err);
    } finally {
      setLoadingPrayers(false);
    }
  }, [user, logout]);

  // Fetch registered mosques
  const fetchMosques = useCallback(async () => {
    try {
      const data = await api.getMosques();
      setMosques(data.mosques);
      offlineSyncService.cacheMosques(data.mosques);
    } catch (err) {
      console.error('Failed to fetch mosques:', err);
    }
  }, []);

  const fetchNasiha = useCallback(async () => {
    try {
      const res = await api.getPublicNasihaList();
      if (res.success && Array.isArray(res.list) && res.list.length > 0) {
        setNasihaList(res.list);
      }
    } catch (err) {
      console.error('Failed to fetch public nasiha:', err);
    }
  }, []);

  useEffect(() => {
    // Show splash screen for a fixed duration on startup
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2500);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    // Fire API calls immediately in parallel without staggered timeouts
    fetchNasiha();
    
    if (user) {
      Promise.allSettled([
        fetchTodayStatus(),
        fetchMosques(),
        fetchNotificationCount()
      ]);
      setShowAuthModal(false);
    }
  }, [user, fetchNasiha, fetchTodayStatus, fetchMosques, fetchNotificationCount]);

  // Daily Hadith rotator
  useEffect(() => {
    const dayIndex = new Date().getDate() % HADITHS.length;
    setRandomHadithIndex(dayIndex);
  }, []);

  // Initialize Offline Sync Service
  useEffect(() => {
    offlineSyncService.init(
      () => {
        fetchTodayStatus();
        refreshUser();
      },
      (type, title, msg) => {
        showToast(type, title, msg);
      }
    );

    const updateOfflineStatus = () => {
      setPendingOfflineItems(offlineSyncService.getPendingCheckIns());
      setIsSyncingOffline(offlineSyncService.getIsSyncing());
      setIsOnline(typeof navigator !== 'undefined' ? navigator.onLine : true);
    };

    window.addEventListener('cave_offline_queue_updated', updateOfflineStatus);
    window.addEventListener('online', updateOfflineStatus);
    window.addEventListener('offline', updateOfflineStatus);

    return () => {
      window.removeEventListener('cave_offline_queue_updated', updateOfflineStatus);
      window.removeEventListener('online', updateOfflineStatus);
      window.removeEventListener('offline', updateOfflineStatus);
    };
  }, [showToast, fetchTodayStatus, refreshUser]);

  // Initialize Prayer Push Reminder Service (local notifications when prayer time starts)
  useEffect(() => {
    prayerReminderService.setInAppReminderCallback((prayerType, nameBn, startTimeStr) => {
      showToast(
        'info',
        `🕌 ${nameBn} সালাতের ওয়াক্ত শুরু হয়েছে`,
        `এখন ${nameBn} সালাতের ওয়াক্ত শুরু হয়েছে (${startTimeStr})। সালাত আদায় করে নিন।`
      );
    });

    prayerReminderService.startScheduler();

    return () => {
      prayerReminderService.stopScheduler();
    };
  }, [showToast]);

  // Global routing and hash change navigation listener
  useEffect(() => {
    (window as any).setAppActiveTab = (tab: any) => {
      setActiveTab(tab);
    };

    const handleHashNavigation = () => {
      const hash = window.location.hash;
      if (!hash) return;
      
      if (hash.startsWith('#shop-')) {
        setActiveTab('shops');
      } else if (hash === '#home') {
        setActiveTab('home');
      } else if (hash === '#tokens') {
        setActiveTab('tokens');
      } else if (hash === '#shops') {
        setActiveTab('shops');
      } else if (hash === '#market') {
        setActiveTab('market');
      } else if (hash === '#profile') {
        setActiveTab('profile');
      } else if (hash === '#merchant') {
        setActiveTab('merchant');
      } else if (hash === '#support') {
        setActiveTab('support');
      } else if (hash === '#notifications') {
        setActiveTab('notifications');
      } else if (hash === '#history' || hash === '#prayer_history' || hash === '#journey' || hash === '#prayer_journey') {
        setActiveTab('prayer_journey');
      } else if (hash === '#admin') {
        setActiveTab('admin');
      } else {
        const tab = hash.substring(1);
        const validTabs = ['home', 'tokens', 'shops', 'market', 'profile', 'merchant', 'admin', 'notifications', 'support', 'history', 'prayer_history', 'prayer_journey'];
        if (validTabs.includes(tab)) {
          setActiveTab(tab as any);
        }
      }
    };

    window.addEventListener('hashchange', handleHashNavigation);
    handleHashNavigation();

    return () => {
      window.removeEventListener('hashchange', handleHashNavigation);
    };
  }, []);

  // Handler for QR scan success
  const handleScanSuccess = async (result: any) => {
    console.log('[TRACE] handleScanSuccess received result object:', JSON.stringify(result, null, 2));
    console.log('[TRACE] result keys:', result ? Object.keys(result) : 'null/undefined');
    console.log('[TRACE] result.success:', result?.success);
    console.log('[TRACE] result.shop:', result?.shop);
    console.log('[TRACE] result.verificationId:', result?.verificationId);

    // Strict verification check before any navigation or modal rendering occurs
    if (!result || result.success !== true) {
      console.warn('[TRACE] Scan failed or success !== true:', result);
      showToast('error', 'ত্রুটি', result?.message || 'ভুল বা অকার্যকর QR কোড স্ক্যান করা হয়েছে। অনুগ্রহ করে সঠিক QR কোড স্ক্যান করুন।');
      return; // Keep user on the scanner screen, do not navigate or update state
    }

    // If shop / redemption verification is present, ensure all required fields exist
    if (result.shop && (!result.shop.id || !result.shop.name || !result.verificationId)) {
      console.warn('[TRACE] Shop data or verificationId is incomplete:', result);
      showToast('error', 'ত্রুটি', 'দোকানের তথ্য অসম্পূর্ণ বা অবৈধ। অনুগ্রহ করে আবার চেষ্টা করুন।');
      return;
    }

    setActiveScanningPrayer(null);
    showToast(
      'success',
      'আলহামদুলিল্লাহ্!',
      result.message || 'আপনার নামাজটি আজকের জন্য সম্পন্ন হিসেবে সংরক্ষণ করা হয়েছে।'
    );

    if (result.tokenResult?.message) {
      showToast('info', '🪙 টোকেন রিওয়ার্ড', result.tokenResult.message);
    }

    // Refresh prayer status and lifetime stats
    await Promise.allSettled([
      fetchTodayStatus(),
      refreshUser()
    ]);
  };

  // Handler for prayer action (Direct verification for Jumu'ah and Female users, QR Scan modal for Male users' other prayers)
  const handlePrayerAction = async (prayer: PrayerInfo) => {
    if (actionLoadingPrayerType) return; // Prevent duplicate clicks or concurrent actions
    const gender = (user?.gender || 'male').toLowerCase();
    if (gender === 'female' || prayer.type === 'jumuah') {
      try {
        setActionLoadingPrayerType(prayer.type);
        const directPayload = prayer.type === 'jumuah' ? 'JUMUAH_DIRECT' : 'FEMALE_DIRECT';
        const result = await api.verifyPrayerQr(prayer.type, directPayload);
        try {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#10b981', '#fbbf24', '#34d399', '#ffffff']
          });
        } catch (e) {}

        showToast(
          'success',
          'আলহামদুলিল্লাহ্!',
          result.message || 'আপনার নামাজটি আজকের জন্য সম্পন্ন হিসেবে সংরক্ষণ করা হয়েছে।'
        );

        if ((result as any).tokenResult?.message) {
          showToast('info', '🪙 টোকেন রিওয়ার্ড', (result as any).tokenResult.message);
        }

        // Refresh status and user concurrently, catch failures gracefully to not crash UI or prevent completion display
        try {
          await Promise.all([
            fetchTodayStatus().catch(err => console.error('Failed to update today status:', err)),
            refreshUser().catch(err => console.error('Failed to refresh user:', err))
          ]);
        } catch (refreshErr) {
          console.error('Refresh failed:', refreshErr);
        }
      } catch (err: any) {
        showToast('error', 'ভেরিফিকেশন ব্যর্থ', err.message || 'সালাত ভেরিফিকেশন করা সম্ভব হয়নি।');
      } finally {
        setActionLoadingPrayerType(null);
      }
    } else {
      setActiveScanningPrayer(prayer);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white p-4">
        <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-sm font-medium text-emerald-300">কেভ কম্প্যানিয়ন্স লোড হচ্ছে...</p>
      </div>
    );
  }

  // Show Splash Screen first regardless of login status
  if (showSplash) {
    return (
      <>
        <ToastContainer toasts={toasts} onDismiss={dismissToast} />
        <SplashScreen
          onStart={() => setShowSplash(false)}
        />
      </>
    );
  }

  // Not logged in: Show Auth Screen
  if (!user) {
    return (
      <>
        <ToastContainer toasts={toasts} onDismiss={dismissToast} />
        <AuthScreen
          onSuccess={() => {
            showToast('success', 'স্বাগতম', 'সফলভাবে লগইন সম্পন্ন হয়েছে!');
          }}
          onCancel={() => setShowSplash(true)}
        />
      </>
    );
  }

  const todayDateStr = todayStatus ? todayStatus.date : new Date().toISOString().split('T')[0];
  const completedCount = todayStatus ? todayStatus.completedCount : 0;

  return (
    <div className="min-h-screen bg-[var(--bg-app)] text-[var(--text-app)] flex flex-col selection:bg-emerald-600 selection:text-white pb-16 transition-colors duration-200">
      {/* Toast Notification Container */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* Top Header */}
      {activeTab === 'home' && (
        <Header
          onOpenMosques={() => setShowMosqueModal(true)}
          onOpenHelp={() => setActiveTab('support')}
          onOpenNotifications={() => setActiveTab('notifications')}
          unreadNotificationsCount={unreadNotificationsCount}
        />
      )}

      {/* Main Content Area */}
      <main className={`flex-1 w-full max-w-2xl mx-auto px-4 pb-5 ${activeTab === 'home' ? 'pt-1.5' : 'pt-5'}`}>
        {/* Tab 1: HOME */}
        {activeTab === 'home' && (
          <div className="space-y-5">
            <AdBanner pageName="HOME" placementSlot="TOP" />
            {/* Daily Progress Counter Card */}
            <DailyProgressCard
              completedCount={completedCount}
              totalPrayers={5}
              dateStr={todayDateStr}
              onViewDetails={() => setShowTodayStatusModal(true)}
              onOpenMosques={() => setShowMosqueModal(true)}
              onOpenJourney={() => setActiveTab('prayer_journey')}
            />

            <AdBanner pageName="HOME" placementSlot="BEFORE_PRODUCTS" />

            {/* Offline Sync Banner (Visible when offline, syncing, or when offline items are pending) */}
            {(pendingOfflineItems.length > 0 || isSyncingOffline || !isOnline) && (
              <div className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 shadow-xs ${
                isSyncingOffline
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-900 dark:text-amber-200'
                  : !isOnline
                  ? 'bg-slate-800/10 border-slate-700/30 text-slate-800 dark:text-slate-200'
                  : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-900 dark:text-emerald-200'
              }`}>
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className={`p-2 rounded-xl shrink-0 ${
                    isSyncingOffline
                      ? 'bg-amber-500/20 text-amber-600 dark:text-amber-400 animate-pulse'
                      : !isOnline
                      ? 'bg-slate-500/20 text-slate-600 dark:text-slate-400'
                      : 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400'
                  }`}>
                    {isSyncingOffline ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : !isOnline ? (
                      <WifiOff className="w-4 h-4" />
                    ) : (
                      <CloudUpload className="w-4 h-4" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold leading-tight truncate">
                      {isSyncingOffline
                        ? 'সার্ভারের সাথে সিঙ্ক হচ্ছে...'
                        : !isOnline
                        ? `ডিভাইস অফলাইনে আছে (${pendingOfflineItems.length}টি পেন্ডিং)`
                        : `অফলাইনে সংরক্ষিত চেক-ইন: ${pendingOfflineItems.length}টি`}
                    </h4>
                    <p className="text-[11px] opacity-80 mt-0.5 leading-snug">
                      {isSyncingOffline
                        ? 'অনুগ্রহ করে অপেক্ষা করুন, সার্ভারে উপস্থিতি যাচাই করা হচ্ছে'
                        : !isOnline
                        ? 'ইন্টারনেট সংযোগ ফিরলে স্বয়ংক্রিয়ভাবে সার্ভারের সাথে সিঙ্ক হবে'
                        : 'ইন্টারনেট চালু হয়েছে। সবগুলো চেক-ইন সার্ভারে পাঠাতে সিঙ্ক করুন'}
                    </p>
                  </div>
                </div>

                {isOnline && !isSyncingOffline && pendingOfflineItems.length > 0 && (
                  <button
                    onClick={() => offlineSyncService.syncPendingCheckIns(true)}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shrink-0 transition cursor-pointer shadow-xs active:scale-95 flex items-center gap-1"
                  >
                    <CloudUpload className="w-3.5 h-3.5" />
                    <span>সিঙ্ক করুন</span>
                  </button>
                )}
              </div>
            )}

            {/* Five Daily Prayers Section */}
            <div className="space-y-3">
              <div className="flex items-center justify-between px-1">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <h2 className="text-base font-bold text-slate-800 dark:text-white tracking-tight">
                    আজকের পাঁচ ওয়াক্ত সালাত
                  </h2>
                </div>

                <button
                  onClick={fetchTodayStatus}
                  className="text-xs text-emerald-600 dark:text-emerald-400/80 hover:text-emerald-500 flex items-center gap-1 transition-colors cursor-pointer"
                  title="রিফ্রেশ করুন"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingPrayers ? 'animate-spin' : ''}`} />
                  <span className="hidden sm:inline">রিফ্রেশ</span>
                </button>
              </div>

              {/* 5 Prayer Cards */}
              <div className="space-y-3">
                {getTodayPrayerOrder(todayDateStr).map(prayerType => {
                  const prayerInfo = PRAYERS_CONFIG[prayerType];
                  const statusItem = todayStatus?.prayers[prayerType] || {
                    completed: false,
                    attendance: null
                  };

                  return (
                    <PrayerCard
                      key={prayerType}
                      prayer={prayerInfo}
                      status={statusItem}
                      userGender={user?.gender}
                      onOpenScan={prayer => handlePrayerAction(prayer)}
                      isVerifying={actionLoadingPrayerType === prayerType}
                    />
                  );
                })}
              </div>
            </div>

            {/* Daily Nasiha Inspiration Card */}
            {(() => {
              const activeSource = nasihaList.length > 0 ? nasihaList : HADITHS;
              const currentItem = activeSource[randomHadithIndex % activeSource.length];
              return (
                <div className="bg-emerald-50/50 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-800/40 rounded-3xl p-5 shadow-xs space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-600 dark:text-amber-300">
                    <BookOpen className="w-4 h-4" />
                    <span>নসিহা</span>
                  </div>
                  <p className="text-xs text-slate-700 dark:text-emerald-100/90 leading-relaxed italic">
                    "{currentItem?.textBn}"
                  </p>
                  {currentItem?.sourceBn && (
                    <p className="text-[11px] text-emerald-600/80 dark:text-amber-400/80 text-right font-medium">
                      — {currentItem.sourceBn}
                    </p>
                  )}
                </div>
              );
            })()}


            {/* Registered Mosques Banner Quick Link */}
            <div
              onClick={() => setShowMosqueModal(true)}
              className="p-4 rounded-2xl bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 hover:border-emerald-500/60 dark:hover:border-emerald-700/60 transition-all cursor-pointer flex items-center justify-between gap-3 group shadow-xs"
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-800/80 group-hover:text-amber-600 dark:group-hover:text-amber-300 transition-colors">
                  <Landmark className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-amber-300 transition-colors">
                    অনুমোদিত মসজিদসমূহ ও QR কোড তালিকা
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    বর্তমানে {mosques.length} টি নিবন্ধিত মসজিদের QR কোড সক্রিয় রয়েছে
                  </p>
                </div>
              </div>
              <span className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold shrink-0">দেখুন →</span>
            </div>
          </div>
        )}

        {/* Tab 2: MY TOKENS (Phase 4 & 5) */}
        {activeTab === 'tokens' && (
          <MyTokenView
            onShowToast={showToast}
            onNavigateToHome={() => setActiveTab('home')}
            onNavigateToShops={() => setActiveTab('shops')}
          />
        )}

        {/* Tab 3: SHOPS (Phase 6) */}
        {activeTab === 'shops' && (
          <ShopsView
            onShowToast={showToast}
            onNavigateToTokens={() => setActiveTab('tokens')}
            onNavigateToMerchant={() => setActiveTab('merchant')}
          />
        )}

        {/* Tab 3.5: CAVE MARKET */}
        {activeTab === 'market' && (
          <CaveMarketView />
        )}

        {/* Tab 4: MERCHANT PORTAL (Phase 7) */}
        {activeTab === 'merchant' && (
          <MerchantPortalView
            onShowToast={showToast}
            onExitMerchant={() => setActiveTab('shops')}
          />
        )}

        {/* Tab 5: PROFILE */}
        {activeTab === 'profile' && (
          <ProfileView
            onLogout={() => {
              logout();
              showToast('info', 'লগআউট', 'আপনি সফলভাবে লগআউট করেছেন।');
            }}
            onShowToast={showToast}
            onNavigateTab={tab => setActiveTab(tab as ActiveTab)}
            onOpenLegal={type => setLegalModalType(type)}
          />
        )}

        {/* Tab 6: NOTIFICATIONS (Phase 8) */}
        {activeTab === 'notifications' && (
          <NotificationsView
            onBack={() => setActiveTab('home')}
            onShowToast={showToast}
            onNotificationReadChange={count => setUnreadNotificationsCount(count)}
          />
        )}

        {/* Tab 7: SALAH JOURNEY & GROWTH (Dedicated Full-Screen View) */}
        {(activeTab === 'prayer_journey' || activeTab === 'prayer_history' || activeTab === 'history') && (
          <SalahJourneyView
            onBack={() => setActiveTab('home')}
            onShowToast={showToast}
          />
        )}

        {/* Tab 8: HELP & SUPPORT (Phase 8) */}
        {activeTab === 'support' && (
          <SupportView
            onBack={() => setActiveTab('profile')}
            onShowToast={showToast}
          />
        )}

        {/* Tab 9: ADMIN DASHBOARD (Phase 9 & 10) */}
        {activeTab === 'admin' && (
          <AdminDashboardView
            onBack={() => setActiveTab('profile')}
            onShowToast={showToast}
          />
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav
        activeTab={
          ['home', 'tokens', 'shops', 'market', 'profile'].includes(activeTab)
            ? (activeTab as any)
            : 'profile'
        }
        onChangeTab={setActiveTab}
      />

      {/* Legal Policy & Terms Modal */}
      <LegalModal
        isOpen={!!legalModalType}
        type={legalModalType}
        onClose={() => setLegalModalType(null)}
      />

      {/* QR Scanner Modal */}
      {activeScanningPrayer && (
        <QRScannerModal
          prayer={activeScanningPrayer}
          mosques={mosques}
          onClose={() => setActiveScanningPrayer(null)}
          onSuccess={handleScanSuccess}
          onErrorToast={(title, msg) => showToast('error', title, msg)}
        />
      )}

      {/* Mosque Directory Modal */}
      {showMosqueModal && (
        <MosqueDirectoryModal
          onClose={() => setShowMosqueModal(false)}
        />
      )}

      {/* Today Prayer Status Detail Modal */}
      {showTodayStatusModal && (
        <TodayPrayerStatusModal
          status={todayStatus}
          userGender={user?.gender}
          onClose={() => setShowTodayStatusModal(false)}
          onOpenScan={prayer => handlePrayerAction(prayer)}
        />
      )}

      {/* Help & FAQ Modal */}
      {showHelpModal && (
        <HelpSupportModal
          onClose={() => setShowHelpModal(false)}
        />
      )}
    </div>
  );
}
