// Service Worker for Prayer Push Notifications & Local Reminders
self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

// Handle incoming Web Push events
self.addEventListener('push', (event) => {
  let data = {};
  if (event.data) {
    try {
      data = event.data.json();
    } catch (e) {
      data = { title: 'সালাতের রিমাইন্ডার', body: event.data.text() };
    }
  }

  const title = data.title || 'সালাতের রিমাইন্ডার';
  const options = {
    body: data.body || 'সালাতের ওয়াক্ত শুরু হতে ১০ মিনিট বাকি।',
    icon: '/app_icon.jpg',
    badge: '/app_icon.jpg',
    vibrate: [200, 100, 200, 100, 300],
    tag: data.tag || 'prayer-reminder',
    renotify: true,
    data: data.url || '/',
    actions: [
      { action: 'open', title: 'অ্যাপমেন্ট খুলুন' }
    ]
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

// Handle notification click
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (let i = 0; i < clientList.length; i++) {
        const client = clientList[i];
        if ('focus' in client) {
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow('/');
      }
    })
  );
});
